# Launching PTG Sites — bolt.new → live on ptgsites.com

This folder is the launch package: the complete static site (63 files, ~3.4MB).
The giant source PNGs were excluded — the site uses optimized .webp images only.
`_headers` adds CSP + security headers on Netlify/production.

## Option A — bolt.new (import, then deploy)
1. Go to **bolt.new** → sign in.
2. **Import** the project:
   - Easiest: upload `ptg-launch.zip` (drag it into the chat/workspace) and ask bolt to extract it as the project root — `index.html` must sit at the root.
   - Or push this folder to a GitHub repo and use bolt's **Import from GitHub**.
3. In bolt, connect **Netlify** (Deploy panel → Netlify → authorize) and click **Deploy**.
   - No build command / no install needed: it is plain static HTML.
   - Publish directory: `/` (the repo root).
4. Bolt gives you a `*.netlify.app` URL — the site is live. Attach the domain (below).

## Option B — skip bolt, direct drag-and-drop (fastest, 2 minutes)
1. Go to **app.netlify.com/drop**.
2. Drag this whole folder (or the unzipped contents) onto the page.
3. Live immediately. Then attach your domain.

## Attach ptgsites.com (works for either option)
1. In the Netlify site: **Domain management → Add a domain** → `ptgsites.com` (add `www` too).
2. At your registrar (wherever ptgsites.com is managed):
   - Either change **nameservers** to Netlify's (Netlify manages DNS), or
   - Add an **A record** `@ → 75.2.60.5` and a **CNAME** `www → <your-site>.netlify.app`.
3. Wait for DNS to propagate (minutes to a few hours). Netlify auto-issues HTTPS.

## Stripe go-live checklist
- `data.js` / `checkout.html` currently use Stripe **Payment Links**. Create them in
  **live mode** (dashboard.stripe.com, toggle Test mode OFF) for each maintenance plan
  ($75 / $99 / $199) and swap the URLs.
- Set the payment link **after-payment redirect** to `https://ptgsites.com/welcome.html`.
- Keep card data off your server — Stripe hosts it. Nothing to PCI-manage beyond that.

## Post-launch checks
- Visit every page: `/`, `/case-study.html?slug=don-patron`, `/checkout.html`,
  `/portal.html`, `/admin.html`, `/privacy.html`, `/terms.html`, `/refund.html`.
- On first `/admin.html` run you set the admin PIN (hashed, never stored in plain text).
- Run a Lighthouse pass (mobile) and submit `sitemap.xml` in Google Search Console.
