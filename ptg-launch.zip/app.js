/* ============================================================
   PTG SITES — ENGINE
   Rendering, motion, interactions, lead capture, analytics.
   One file, guards by element presence so it works on every page.
   ============================================================ */
(function () {
  'use strict';

  document.documentElement.classList.add('js');

  /* ----------------------------- helpers ----------------------------- */
  const $  = (s, c) => (c || document).querySelector(s);
  const $$ = (s, c) => Array.from((c || document).querySelectorAll(s));

  // XSS-safe rendering: everything that can be edited via the admin dashboard
  // (and therefore via localStorage) must pass through esc() before innerHTML.
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  };

  /* ----------------------------- cookie / storage consent ----------------------------- */
  // We only use localStorage (no third-party cookies, no ad trackers), but we
  // still ask before recording any usage analytics. Choice is remembered.
  const consent = store.get('ptg_consent', null);
  const consentGranted = () => store.get('ptg_consent', null) === 'granted';

  function ensureConsentBanner() {
    if (consent !== null || $('[data-consent-banner]')) return;
    const el = document.createElement('div');
    el.className = 'consent-banner';
    el.setAttribute('data-consent-banner', '');
    el.setAttribute('role', 'dialog');
    el.setAttribute('aria-label', 'Privacy preferences');
    el.innerHTML =
      '<div class="cb-text"><b>Your privacy, briefly.</b>' +
      '<p>We use browser storage only to remember your preferences and — if you allow it — anonymous usage stats that help us improve this site. No ad trackers, no data sales.</p>' +
      '<a href="privacy.html">Privacy Policy</a></div>' +
      '<div class="cb-actions"><button class="btn btn-ghost btn-sm" data-consent="denied">Decline</button>' +
      '<button class="btn btn-primary btn-sm" data-consent="granted">Accept</button></div>';
    document.body.appendChild(el);
    requestAnimationFrame(() => el.classList.add('show'));
    el.addEventListener('click', (e) => {
      const b = e.target.closest('[data-consent]');
      if (!b) return;
      store.set('ptg_consent', b.dataset.consent);
      el.classList.remove('show');
      setTimeout(() => el.remove(), 450);
      if (b.dataset.consent === 'granted') track('consent_granted');
    });
  }

  // Accessibility default: honor the OS reduced-motion setting. For previewing
  // the full motion design, override with ?motion=1 or localStorage ptg_motion.
  const motionOverride = new URLSearchParams(location.search).get('motion') === '1' || store.get('ptg_motion') === 'on';
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches && !motionOverride;
  const isTouch = window.matchMedia('(pointer: coarse)').matches;
  const hasGsap = typeof window.gsap !== 'undefined' && typeof window.ScrollTrigger !== 'undefined';
  const hasLenis = typeof window.Lenis !== 'undefined';

  const S = window.PTG || {};
  const SET = S.settings || {};

  // Admin overrides (saved by admin.html) win over the static data.
  const OVER = store.get('ptg_admin_overrides', null);
  if (OVER) {
    Object.keys(OVER).forEach((k) => { if (S[k]) S[k] = OVER[k]; });
    if (OVER.settings) Object.assign(SET, OVER.settings);
  }

  const projects = S.projects || [];
  const services = S.services || [];
  const process  = S.process  || [];
  const pricing  = S.pricing  || [];
  const plans    = S.plans    || [];
  const faqs     = S.faqs     || [];
  const journal  = S.journal  || [];

  /* ----------------------------- analytics ----------------------------- */
  function track(type, label, extra) {
    if (!consentGranted()) return; // analytics stay off until the visitor accepts
    if (!SET.analytics || SET.analytics.enabled === false) return;
    const evts = store.get('ptg_events', []);
    evts.push({ t: type, l: label || '', ts: Date.now(), p: location.pathname, u: location.href, e: extra || {} });
    store.set('ptg_events', evts.slice(-4000));
  }

  // CTA click analytics — label with the CTA text + the section it lives in.
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a.btn, button.btn, [data-open-modal], [data-plan], [data-price]');
    if (!a) return;
    const section = a.closest('section') || a.closest('div');
    const where = (section && (section.id || section.dataset.section)) || 'unknown';
    const text = (a.dataset.plan || a.dataset.price || a.dataset.openModal || a.textContent.trim()).slice(0, 60);
    track('cta_click', where + ' :: ' + text);
  });

  /* ----------------------------- live mini-previews ----------------------------- */
  // Real, scrollable, interactive miniatures of the client sites. Each
  // .live-preview element keeps a lightweight poster image and swaps in a
  // scaled iframe once it approaches the viewport. Iframes are queued so only
  // one heavy site loads at a time, and skipped entirely on save-data.
  const liveQueue = [];
  let liveActive = 0;
  const liveMounted = new Map();   // el -> { wrap, timers } for teardown
  const NEAR = 420;                // px beyond the viewport a frame stays mounted
  const MAX_ACTIVE = (navigator.hardwareConcurrency || 4) <= 4 ? 1 : 2; // parallel iframe loads
  let liveSweepArmed = false;

  function initLivePreviews(scope) {
    const nodes = $$('.live-preview', scope || document);
    if (!nodes.length) return;
    if (navigator.connection && navigator.connection.saveData) return; // posters only
    nodes.forEach((el) => {
      if (el.dataset.liveBound) return;
      el.dataset.liveBound = '1';
    });
    if (liveSweepArmed) { sweepLive(); return; }
    liveSweepArmed = true;
    sweepLive();
    // Geometry sweep instead of IntersectionObserver: IO proved unreliable in
    // embedded webviews (callbacks never fired), and with ~a dozen frames a
    // rAF-throttled rect check is trivial. It also gives us teardown for free:
    // frames unmount when they scroll away, so a long page never accumulates
    // live iframes — that accumulation was the main source of lag.
    let ticking = false;
    const onMove = () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => { ticking = false; sweepLive(); });
    };
    window.addEventListener('scroll', onMove, { passive: true });
    window.addEventListener('resize', onMove, { passive: true });
    window.addEventListener('load', onMove, { passive: true, once: true });
    setTimeout(onMove, 1600); // late layout shifts (webfonts, images) with no scroll
    setTimeout(onMove, 4000);
  }

  function sweepLive() {
    // Prune entries whose host nodes were removed (e.g. portfolio filter
    // re-renders) so detached frames can't leak timers or queue slots.
    for (const [el, rec] of [...liveMounted]) {
      if (!el.isConnected) {
        liveMounted.delete(el);
        clearTimeout(rec.readyT);
        clearTimeout(rec.watchdog);
        if (rec.release) rec.release();
      }
    }
    $$('.live-preview[data-live-bound]').forEach((el) => {
      const r = el.getBoundingClientRect();
      // Zero-size rects mean the element is hidden (display:none subtree, e.g.
      // the hero composition on phones) — never mount those.
      const visible = r.width > 0 && r.height > 0;
      const near = visible && r.top < window.innerHeight + NEAR && r.bottom > -NEAR;
      if (near && !el.dataset.liveQueued && !liveMounted.has(el)) {
        el.dataset.liveQueued = '1';
        liveQueue.push({ el, url: el.dataset.liveUrl, vw: +(el.dataset.liveVw || 0), title: el.dataset.liveTitle || 'Live website preview' });
      } else if (!near && liveMounted.has(el)) {
        teardownLive(el);
      }
    });
    pumpLive();
  }

  function pumpLive() {
    while (liveActive < MAX_ACTIVE && liveQueue.length) {
      const job = liveQueue.shift();
      if (!job.el.isConnected || liveMounted.has(job.el)) continue;
      const r = job.el.getBoundingClientRect();
      if (!r.width || !r.height || r.top >= window.innerHeight + NEAR || r.bottom <= -NEAR) {
        delete job.el.dataset.liveQueued; // hidden or scrolled away while queued
        continue;
      }
      liveActive++;
      buildLiveFrame(job, () => { liveActive--; pumpLive(); });
    }
  }

  function teardownLive(el) {
    const rec = liveMounted.get(el);
    if (!rec) return;
    liveMounted.delete(el);
    clearTimeout(rec.readyT);
    clearTimeout(rec.watchdog);
    rec.wrap.remove();
    delete el.dataset.liveQueued; // eligible to remount when scrolled back
    el.classList.remove('live-on', 'live-ready');
    if (rec.release) rec.release(); // free the queue slot if the frame was still loading
  }

  function buildLiveFrame(job, done) {
    const { el, url, title } = job;
    let released = false;
    const release = () => { if (!released) { released = true; done(); } };
    const w = el.clientWidth || 800;
    const h = el.clientHeight || 420;
    // Render the iframe at (or near) its natural on-screen pixel size instead
    // of a fixed 1440px virtual viewport scaled down — a 3-6x pixel overrun
    // that made every frame render and composite far more than it displayed.
    // Only previews that explicitly opt in (data-live-vw, e.g. phone frames)
    // use a virtual viewport.
    const vw = job.vw || Math.max(320, Math.round(w));
    const scale = w / vw;
    const external = /^https?:/i.test(url);
    // External embeds render extra viewport below the visible area so fixed
    // corner badges on the embedded site (e.g. builder badges) end up in the
    // cropped zone instead of on top of the showcase.
    const badgeCrop = external ? Math.ceil(72 * scale) : 0;
    const wrap = document.createElement('div');
    wrap.className = 'live-frame';
    wrap.setAttribute('data-lenis-prevent', '');
    const ifr = document.createElement('iframe');
    ifr.title = title;
    ifr.setAttribute('src', url);
    ifr.setAttribute('tabindex', '-1');
    ifr.setAttribute('loading', 'lazy');
    ifr.setAttribute('allow', 'autoplay');
    ifr.setAttribute('referrerpolicy', 'no-referrer-when-downgrade');
    ifr.style.width = vw + 'px';
    ifr.style.height = Math.round(h / scale) + Math.round(badgeCrop / scale) + 'px';
    ifr.style.transform = 'scale(' + scale + ')';
    ifr.style.transformOrigin = '0 0';
    wrap.style.height = h + badgeCrop + 'px'; // visible area stays h; the extra bottom is cropped
    wrap.appendChild(ifr);
    el.classList.add('live-on');
    el.appendChild(wrap);
    const readyT = setTimeout(() => el.classList.add('live-ready'), external ? 2500 : 250);
    // Watchdog only covers frames that NEVER finish loading (frees the queue
    // slot and falls back to the poster). Successful loads cancel it —
    // otherwise every frame would self-destruct 18s after mounting.
    const watchdog = setTimeout(() => { teardownLive(el); release(); }, 18000);
    liveMounted.set(el, { wrap, readyT, watchdog, release });
    ifr.addEventListener('load', () => { clearTimeout(watchdog); release(); });
  }

  /* ----------------------------- form spam protection ----------------------------- */
  // Honeypot field + time-trap + per-form throttle. Client-side deterrence;
  // server-side validation lives in the Apps Script backend.
  function spamGuard(form) {
    const honey = form.querySelector('[name="pt_hp"]');
    if (honey && honey.value) return 'Spam detected.';
    const t0 = +(form.dataset.renderedTs || 0);
    if (t0 && Date.now() - t0 < 2500) return 'That was too fast — please try again.';
    const key = 'ptg_form_ts_' + (form.id || 'form');
    const last = +(store.get(key, 0) || 0);
    if (last && Date.now() - last < 20000) return 'Please wait a few seconds before submitting again.';
    store.set(key, Date.now());
    return null;
  }
  function armSpamGuard(form) {
    if (!form || form.dataset.spamArmed) return;
    form.dataset.spamArmed = '1';
    form.dataset.renderedTs = String(Date.now());
    if (!form.querySelector('[name="pt_hp"]')) {
      const hp = document.createElement('input');
      hp.type = 'text'; hp.name = 'pt_hp'; hp.tabIndex = -1;
      hp.setAttribute('autocomplete', 'off'); hp.setAttribute('aria-hidden', 'true');
      hp.style.cssText = 'position:absolute;left:-9999px;height:0;width:0;opacity:0;pointer-events:none;';
      form.appendChild(hp);
    }
  }

  /* ----------------------------- shared shell (sub-pages) ----------------------------- */
  function injectShell() {
    const isIndex = /(^|\/)index\.html$/.test(location.pathname) || location.pathname.endsWith('/');
    const h = (id) => (isIndex ? '#' : 'index.html#') + id;
    const navHost = $('[data-shell="nav"]');
    if (navHost) {
      navHost.innerHTML =
        '<header class="nav scrolled" id="nav">' +
          '<div class="nav-inner">' +
            '<a href="' + (isIndex ? 'index.html' : 'index.html') + '" class="nav-logo">PTG<span class="dot">.</span>SITES</a>' +
            '<nav class="nav-links" aria-label="Primary">' +
              '<a href="' + h('work') + '" data-i18n="nav.work">Work</a><a href="' + h('services') + '" data-i18n="nav.services">Services</a>' +
              '<a href="' + h('process') + '" data-i18n="nav.process">Process</a><a href="' + h('maintenance') + '" data-i18n="nav.maintenance">Maintenance</a>' +
              '<a href="' + h('why') + '" data-i18n="nav.about">About</a><a href="' + h('faq') + '" data-i18n="nav.faq">FAQ</a>' +
            '</nav>' +
            '<div class="nav-actions"><button class="lang-toggle" type="button" aria-pressed="false" aria-label="Cambiar a Español">' +
              '<span class="lt-opt" data-i18n="lang.en">EN</span><span class="lt-knob" aria-hidden="true"></span><span class="lt-opt" data-i18n="lang.es">ES</span></button></div>' +
            '<button class="btn btn-primary btn-sm nav-cta" data-open-modal="project" data-i18n="nav.start">Start Your Project <span class="arr">→</span></button>' +
            '<button class="nav-burger" id="navBurger" aria-label="Open menu" aria-expanded="false"><i></i><i></i><i></i></button>' +
          '</div>' +
        '</header>' +
        '<div class="menu" id="menu" aria-hidden="true">' +
          '<button class="menu-close" id="menuClose" aria-label="Close menu">✕</button>' +
          '<a class="menu-link" href="' + h('work') + '">Work</a>' +
          '<a class="menu-link" href="' + h('services') + '">Services</a>' +
          '<a class="menu-link" href="' + h('process') + '">Process</a>' +
          '<a class="menu-link" href="' + h('maintenance') + '">Maintenance</a>' +
          '<a class="menu-link" href="' + h('why') + '">About</a>' +
          '<a class="menu-link" href="' + h('faq') + '">FAQ</a>' +
          '<a class="menu-link" href="' + h('journal') + '">Journal</a>' +
          '<div class="menu-foot"><span data-i18n="nav.start">Start your project →</span><span>' + (SET.phone || '') + '</span></div>' +
          '<div class="menu-actions"><button class="lang-toggle" type="button" aria-pressed="false" aria-label="Cambiar a Español">' +
            '<span class="lt-opt" data-i18n="lang.en">EN</span><span class="lt-knob" aria-hidden="true"></span><span class="lt-opt" data-i18n="lang.es">ES</span></button></div>' +
        '</div>';
    }
    const footHost = $('[data-shell="footer"]');
    if (footHost) {
      footHost.innerHTML =
        '<footer class="footer" id="footer">' +
          '<div class="container">' +
            '<div class="footer-grid">' +
              '<div class="footer-brand">' +
                '<a href="' + (isIndex ? 'index.html' : 'index.html') + '" class="nav-logo">PTG<span class="dot">.</span>SITES</a>' +
                '<p>' + (SET.tagline || 'Websites built to make businesses look better, work better, and grow.') + '</p>' +
                '<div class="footer-socials" id="socials"></div>' +
              '</div>' +
              '<div class="footer-col"><h4>Explore</h4>' +
                '<a href="' + h('work') + '">Work</a><a href="' + h('services') + '">Services</a><a href="' + h('process') + '">Process</a>' +
                '<a href="' + h('maintenance') + '">Maintenance</a><a href="' + h('why') + '">About</a><a href="' + h('faq') + '">FAQ</a>' +
              '</div>' +
              '<div class="footer-col"><h4>Company</h4>' +
                '<a href="index.html">Home</a><a href="audit.html">Free Website Audit</a>' +
                '<a href="admin.html">Admin Dashboard</a><a href="portal.html">Client Portal</a>' +
              '</div>' +
              '<div class="footer-col"><h4>Contact</h4>' +
                '<a href="mailto:' + (SET.email || 'hello@ptgsites.com') + '">' + (SET.email || 'hello@ptgsites.com') + '</a>' +
                '<a href="' + (SET.phoneHref || '#') + '">' + (SET.phone || '') + '</a>' +
                '<a href="#" data-open-modal="project">Start A Project</a><a href="#" data-open-modal="book">Book A Call</a>' +
              '</div>' +
            '</div>' +
            '<div class="footer-bottom">' +
              '<span>© <span id="year"></span> ' + (SET.legalName || 'Pinnacle Tech Group Sites') + '. All rights reserved.</span>' +
              '<div class="legal"><a href="privacy.html">Privacy</a><a href="terms.html">Terms</a><a href="refund.html">Refund Policy</a><a href="maintenance-agreement.html">Maintenance Agreement</a><a href="#" data-open-consent>Cookie Preferences</a></div>' +
            '</div>' +
          '</div>' +
        '</footer>' +
        '<div class="sticky-bar"><a href="#" class="btn btn-primary" data-open-modal="project">Start Your Project <span class="arr">→</span></a></div>';
    }
    // Shared modals — single source of truth for every page (incl. homepage).
    if (!$('#modal-project')) {
      const modals = document.createElement('div');
      modals.innerHTML = projectModalHTML() + bookModalHTML() + legalModalHTML();
      while (modals.firstChild) document.body.appendChild(modals.firstChild);
    }
  }

  function projectModalHTML() {
    return (
      '<div class="modal" id="modal-project" role="dialog" aria-modal="true" aria-label="Start your project">' +
        '<div class="modal-card wide">' +
          '<button class="modal-close" data-close-modal aria-label="Close">✕</button>' +
          '<div class="form-view">' +
            '<h3 class="modal-title">Start Your Project</h3>' +
            '<p class="modal-sub">Tell us about your business and what you need. We\'ll review your requirements and get back to you with a plan — usually within one business day.</p>' +
            '<form id="projectForm" novalidate>' +
              '<div class="form-grid">' +
                '<div class="field"><label for="pf-name">Name *</label><input id="pf-name" name="name" required autocomplete="name" placeholder="Your name"></div>' +
                '<div class="field"><label for="pf-business">Business Name</label><input id="pf-business" name="business" autocomplete="organization" placeholder="Business name"></div>' +
                '<div class="field"><label for="pf-email">Email *</label><input id="pf-email" name="email" type="email" required autocomplete="email" placeholder="you@business.com"></div>' +
                '<div class="field"><label for="pf-phone">Phone</label><input id="pf-phone" name="phone" type="tel" autocomplete="tel" placeholder="(555) 000-0000"></div>' +
                '<div class="field"><label for="pf-website">Current Website</label><input id="pf-website" name="website" placeholder="https://yourbusiness.com"></div>' +
                '<div class="field"><label for="pf-industry">Industry</label><select id="pf-industry" name="industry"></select></div>' +
                '<div class="field"><label for="pf-need">What Do You Need?</label><select id="pf-need" name="need"></select></div>' +
                '<div class="field"><label for="pf-budget">Budget</label><select id="pf-budget" name="budget"></select></div>' +
                '<div class="field"><label for="pf-timeline">Timeline</label><select id="pf-timeline" name="timeline"></select></div>' +
                '<div class="field full"><label for="pf-details">Tell Us About Your Project *</label><textarea id="pf-details" name="details" required placeholder="What does your business do? What should the website accomplish?"></textarea></div>' +
                '<div class="field full"><button type="submit" class="btn btn-primary btn-block">Get My Project Plan <span class="arr">→</span></button>' +
                '<p class="form-note">By submitting, you agree to be contacted about your project. No spam, no lists — ever.</p></div>' +
              '</div>' +
            '</form>' +
          '</div>' +
          '<div class="form-success" id="projectSuccess">' +
            '<div class="fs-ico">✓</div>' +
            '<h3>Request Received.</h3>' +
            '<p>Thanks for reaching out to PTG Sites. We\'ve received your project request and will review your requirements — expect to hear from us within one business day.</p>' +
            '<a href="#" class="btn btn-ghost" data-close-modal>Back To Site</a>' +
          '</div>' +
        '</div>' +
      '</div>'
    );
  }

  function bookModalHTML() {
    return (
      '<div class="modal" id="modal-book" role="dialog" aria-modal="true" aria-label="Book a discovery call">' +
        '<div class="modal-card">' +
          '<button class="modal-close" data-close-modal aria-label="Close">✕</button>' +
          '<div class="form-view">' +
            '<h3 class="modal-title">Book A Discovery Call</h3>' +
            '<p class="modal-sub">A relaxed 20-minute conversation about your business and what you need online. No pressure, no pitch — just a plan.</p>' +
            '<div class="booking-steps" id="bookingSteps">' +
              '<div class="booking-step active" data-step="1">' +
                '<div class="booking-meta"><span class="booking-back">1 / 3 — Meeting Type</span><div class="booking-progress"><i class="done"></i><i></i><i></i></div></div>' +
                '<div class="field" style="margin-bottom:16px"><label for="bk-type">Meeting Type</label><select id="bk-type"></select></div>' +
                '<div class="field" style="margin-bottom:16px"><label for="bk-tz">Your Timezone</label><select id="bk-tz"></select></div>' +
                '<button class="btn btn-primary btn-block" data-bk-next>Continue <span class="arr">→</span></button>' +
              '</div>' +
              '<div class="booking-step" data-step="2">' +
                '<div class="booking-meta"><span class="booking-back"><button class="booking-back" data-bk-back>← Back</button></span><div class="booking-progress"><i class="done"></i><i class="done"></i><i></i></div></div>' +
                '<div class="day-grid" id="bkDays"></div>' +
                '<div class="time-grid" id="bkTimes"></div>' +
                '<button class="btn btn-primary btn-block" data-bk-next disabled id="bkTimeNext">Continue <span class="arr">→</span></button>' +
              '</div>' +
              '<div class="booking-step" data-step="3">' +
                '<div class="booking-meta"><span class="booking-back"><button class="booking-back" data-bk-back>← Back</button></span><div class="booking-progress"><i class="done"></i><i class="done"></i><i class="done"></i></div></div>' +
                '<div class="form-grid">' +
                  '<div class="field"><label for="bk-name">Name *</label><input id="bk-name" required placeholder="Your name"></div>' +
                  '<div class="field"><label for="bk-email">Email *</label><input id="bk-email" type="email" required placeholder="you@business.com"></div>' +
                  '<div class="field full"><label for="bk-notes">What should we talk about?</label><textarea id="bk-notes" placeholder="Optional — your business, your website, anything worth knowing before we talk."></textarea></div>' +
                  '<div class="field full"><button type="submit" class="btn btn-primary btn-block" id="bkSubmit">Confirm My Call <span class="arr">→</span></button></div>' +
                '</div>' +
              '</div>' +
            '</div>' +
          '</div>' +
          '<div class="form-success" id="bookSuccess">' +
            '<div class="fs-ico">✓</div>' +
            '<h3>Call Booked.</h3>' +
            '<p id="bookSummary">Your discovery call is confirmed. We\'ll send a calendar invite and reminder to your email.</p>' +
            '<a href="#" class="btn btn-ghost" data-close-modal>Back To Site</a>' +
          '</div>' +
        '</div>' +
      '</div>'
    );
  }

  function legalModalHTML() {
    return (
      '<div class="modal" id="modal-legal" role="dialog" aria-modal="true" aria-label="Legal documents">' +
        '<div class="modal-card">' +
          '<button class="modal-close" data-close-modal aria-label="Close">✕</button>' +
          '<h3 class="modal-title" id="legalTitle">Legal</h3>' +
          '<div class="legal-body" id="legalBody" style="color:var(--ink-dim);font-size:14.5px;line-height:1.7"></div>' +
        '</div>' +
      '</div>'
    );
  }

  /* ----------------------------- boot order ----------------------------- */
  let lenis = null;
  function initLenis() {
    if (!hasLenis || reduced || isTouch) return;
    lenis = new Lenis({ duration: 1.15, smoothWheel: true });
    window.lenis = lenis; /* exposed for programmatic scroll + debugging */
    if (hasGsap) {
      lenis.on('scroll', window.ScrollTrigger.update);
      gsap.ticker.add((time) => { lenis.raf(time * 1000); });
      gsap.ticker.lagSmoothing(0);
    }
  }

  function initSmoothAnchors() {
    document.addEventListener('click', (e) => {
      const a = e.target.closest('a[href^="#"]');
      if (!a) return;
      const id = a.getAttribute('href');
      if (id.length < 2) return;
      const el = $(id);
      if (!el) return;
      e.preventDefault();
      const y = el.getBoundingClientRect().top + window.scrollY - 68;
      if (lenis) lenis.scrollTo(y, { duration: 1.2 });
      else window.scrollTo({ top: y, behavior: reduced ? 'auto' : 'smooth' });
    });
  }

  /* ----------------------------- loader + hero ----------------------------- */
  function runLoader() {
    const loader = $('#loader');
    if (!loader) return;
    const word = $('#loaderWord');
    const text = 'PTG SITES';
    if (word) {
      word.innerHTML = text.split('').map((ch) => '<i>' + (ch === ' ' ? '&nbsp;' : ch) + '</i>').join('');
      $$('i', word).forEach((i, n) => setTimeout(() => i.classList.add('on'), 120 + n * 45));
    }
    const done = () => {
      if (hasGsap) {
        gsap.to(loader, { autoAlpha: 0, duration: 0.55, ease: 'power2.out', delay: 0.1, onComplete: () => { loader.style.display = 'none'; heroSequence(); } });
      } else {
        loader.style.display = 'none';
        heroSequence();
      }
    };
    setTimeout(done, reduced ? 150 : 1000);
  }

  function heroSequence() {
    if (!hasGsap) {
      $$('.hero .line > span, .hero-kicker, .hero-sub, .hero-ctas, .hero-micro, #heroScroll, .hero-visual .frame')
        .forEach((el) => { el.style.opacity = 1; el.style.transform = 'none'; });
      return;
    }
    const tl = gsap.timeline({ defaults: { ease: 'power4.out' } });
    tl.to('.hero-kicker', { autoAlpha: 1, duration: 0.7 }, 0.1)
      .to('.hero-title .line > span', { yPercent: 0, duration: 1.05, stagger: 0.11 }, 0.22)
      .to('.hero-sub', { autoAlpha: 1, y: 0, duration: 0.8 }, 0.75)
      .to('.hero-ctas', { autoAlpha: 1, y: 0, duration: 0.8 }, 0.9)
      .to('.hero-micro', { autoAlpha: 1, duration: 0.7 }, 1.05)
      .to('#heroScroll', { autoAlpha: 1, duration: 0.7 }, 1.15);

    const frames = $$('.hero-visual .frame');
    frames.forEach((f, i) => {
      gsap.set(f, {
        opacity: 0,
        y: 60 + i * 20,
        rotate: i === 1 ? 7 : i === 2 ? 3 : -2.5,
        scale: 0.94
      });
      tl.to(f, { opacity: 1, y: 0, rotate: i === 1 ? 4 : i === 2 ? 2.5 : 0, scale: 1, duration: 1.3, ease: 'power3.out' }, 0.5 + i * 0.18);
    });
    tl.to('.frame-tag', { autoAlpha: 1, duration: 0.6 }, 1.5);

    // No perpetual drift: infinite tweens over frames that contain live
    // iframes force continuous recompositing of those layers and were a real
    // source of jank. The entrance animation + scroll parallax carry the motion.

    // parallax out on scroll
    gsap.to('.hero-visual', {
      yPercent: 14, opacity: 0.35, ease: 'none',
      scrollTrigger: { trigger: '#hero', start: 'top top', end: 'bottom top', scrub: 0.6 }
    });
    gsap.to('.hero-copy', {
      yPercent: -8, opacity: 0.3, ease: 'none',
      scrollTrigger: { trigger: '#hero', start: 'top top', end: 'bottom top', scrub: 0.6 }
    });
  }

  /* ----------------------------- language toggle / translate layer ----------------------------- */
  // Lightweight EN / ES toggle. English is authored directly in the HTML;
  // Spanish is driven by a dictionary that covers chrome (nav, labels,
  // buttons, footer) — not the marketing body copy, which would be
  // human-translated per page for a real release.
  //
  //   - Remembers the choice (ptg_lang in localStorage).
  //   - Flips <html lang> (accessibility / SEO / form validation hints).
  //   - Drives [data-i18n="key"] text nodes and [data-i18n-html="key"]
  //     HTML nodes.
  //   - Keys that are missing from the ES dict fall back to the authored
  //     English so nothing goes blank.
  const LS_LANG = 'ptg_lang';
  const Lang = {
    dict: {
      // ---- nav ----
      'nav.work': 'Trabajos',
      'nav.services': 'Servicios',
      'nav.process': 'Proceso',
      'nav.maintenance': 'Mantenimiento',
      'nav.about': 'Nosotros',
      'nav.faq': 'FAQ',
      'nav.journal': 'Blog',
      'nav.start': 'Inicia tu proyecto',
      'nav.menuOpen': 'Abrir menú',
      'nav.menuClose': 'Cerrar menú',
      'nav.phone': 'Llámanos',

      // ---- hero ----
      'hero.eyebrow': 'Pinnacle Tech Group — Boston, MA',
      'hero.cta1': 'Inicia tu sitio  →',
      'hero.cta2': 'Ver nuestro trabajo',
      'hero.micro': 'Diseño Web · E-Commerce · Reservas · Mantenimiento',
      'hero.scroll': 'Desliza',

      // ---- marquee ----
      'mq.web': 'Diseño Web', 'mq.ecom': 'E-Commerce', 'mq.book': 'Sistemas de Reserva',
      'mq.order': 'Pedidos Online', 'mq.maint': 'Mantenimiento', 'mq.redesign': 'Rediseños',
      'mq.custom': 'Desarrollo a Medida', 'mq.location': 'Boston · Massachusetts',

      // ---- work ----
      'work.label': 'Trabajos Seleccionados',
      'work.title': 'Hechos para el mundo real.',
      'work.lead': 'Sitios web diseñados sobre negocios reales, clientes reales y objetivos reales. Sin plantillas, sin historias de stock — estas son presencias digitales vivas y funcionando.',
      'work.start': 'Inicia un proyecto como este →',

      // ---- services ----
      'svc.label': 'Lo que construimos',
      'svc.title': 'Todo lo que tu negocio necesita en línea.',
      'svc.ask': '¿No estás seguro de lo que necesitas? Cuéntanos qué hace tu negocio y te recomendamos la construcción correcta.',

      // ---- the math / bad ----
      'bad.label': 'Las cuentas',
      'bad.title': 'Un mal sitio web es costoso.',
      'bad.lead': 'Los clientes juzgan rápido. Si tu sitio se ve viejo, carga lento, no funciona en el móvil, o hace difícil contactarte — se van antes de que tengas la chance de ganarlos.',
      'bad.costH': 'Costándote clientes',
      'bad.costP': 'Cada visitante que se va, en silencio.',
      'bad.newH': 'Trabajando para ti',
      'bad.newP': 'Representándote a todas las horas.',
      'bad.verdict': 'Tu sitio web es tu representante de ventas 24/7. Contrata a uno bueno.',
      'bad.build': 'Construye mi sitio →',

      // ---- process ----
      'proc.label': 'El proceso de PTG',
      'proc.title': 'Siete pasos. Cero adivinanzas.',
      'proc.lead': 'Un camino claro de la primera conversación al sitio web en vivo — y más allá. Siempre sabes qué pasa, qué sigue, y cuándo sale.',

      // ---- why ----
      'why.label': 'Por qué PTG Sites',
      'why.title': 'Otra agencia de plantillas, no.',
      'why.lead': 'La diferencia entre un sitio web y un sitio web que funciona es todo. Esta es la norma que aplicamos a cada construcción.',

      // ---- pricing ----
      'price.label': 'Proyectos web',
      'price.title': 'Precios honestos. Trabajo serio.',
      'price.lead': 'Un número claro antes de empezar. El precio que cotizamos es el precio que pagas — dividido en hitos para que nunca pagues por trabajo que no sucedió.',
      'price.custom': '¿Necesitas algo más allá de Máximo — portales personalizados, multi-ubicación, integraciones pesadas? Pide un presupuesto personalizado →',

      // ---- budget ----
      'budget.label': 'Presupuestos flexibles',
      'budget.title': '¿Tienes un presupuesto a medida en mente?',
      'budget.lead': 'Los paquetes de arriba son puntos de partida, no puertas. Si trabajas con un presupuesto más pequeño — o una visión más grande — mándanos tu número. Cuéntanos qué necesita hacer el sitio y te diremos honestamente qué toma llegar ahí.',
      'budget.run': 'Pásame mi presupuesto por PTG →',

      // ---- maintenance ----
      'maint.label': 'Mantenimiento web',
      'maint.title': 'Tu sitio no debería volverse tu problema.',
      'maint.lead': 'Tu sitio no deja de necesitar atención cuando sale. PTG Sites mantiene tu presencia digital mantenida, actualizada, monitorizada y lista para tus clientes.',
      'billing.monthly': 'Mensual',
      'billing.yearly': 'Anual  −17%',

      // ---- audit ----
      'audit.label': 'Auditoría gratuita',
      'audit.title': '¿No estás seguro de si tu sitio funciona?',
      'audit.lead': 'Evaluamos tu sitio actual en diseño, móvil, velocidad, conversión y SEO — y te decimos exactamente qué te está costando clientes. Evaluación honesta, sin guion de ventas.',
      'audit.cta': 'Obtén una auditoría gratuita →',

      // ---- proof ----
      'proof.q': 'Hechos para negocios listos para verse la cara.',

      // ---- journal ----
      'journal.label': 'El blog de PTG',
      'journal.title': 'Respuestas directas sobre sitios web.',

      // ---- faq ----
      'faq.label': 'Preguntas',
      'faq.title': 'Preguntado y respondido.',
      'faq.ask': '¿Algo más en tu mente? Pregúntanos directamente →',

      // ---- final ----
      'final.title': 'LISTO PARA VERLO',
      'final.sub': 'Construyamos un sitio que haga imposible pasar por alto a tu negocio.',
      'final.cta1': 'Inicia mi proyecto →',
      'final.book': 'Reserva una llamada',

      // ---- keep ----
      'keep.h': 'Y cuando lanzamos… podemos seguirlo haciendo funcionar.',
      'keep.p': 'Únete a un plan de mantenimiento de PTG y dejamos que nos encarguemos del trabajo técnico mientras tú te encargas de tu negocio.',
      'keep.view': 'Ver planes de mantenimiento →',

      // ---- footer ----
      'f.tag': 'Sitios web hechos para que los negocios se vean mejor, funcionen mejor y crezcan.',
      'f.explore': 'Explorar',
      'f.company': 'Empresa',
      'f.contact': 'Contacto',
      'f.home': 'Inicio',
      'f.audit': 'Auditoría gratuita',
      'f.admin': 'Panel de administración',
      'f.portal': 'Panel del cliente',
      'f.cases': 'Casos de estudio',
      'f.work': 'Trabajos', 'f.services': 'Servicios', 'f.process': 'Proceso',
      'f.maintenance': 'Mantenimiento', 'f.about': 'Nosotros', 'f.faq': 'FAQ', 'f.journal': 'Blog',
      'f.email': 'hello@ptgsites.com',
      'f.privacy': 'Política de privacidad',
      'f.terms': 'Términos',
      'f.refund': 'Política de reembolso',
      'f.agreement': 'Acuerdo de mantenimiento',
      'f.cookie': 'Preferencias de cookies',
      'f.legal': 'Documentos legales',
      'f.copyright': 'Todos los derechos reservados.',

      // ---- modals ----
      'm.project.title': 'Inicia tu proyecto',
      'm.project.sub': 'Cuéntanos sobre tu negocio y lo que necesitas. Revisamos tus requisitos y te respondemos con un plan — usualmente dentro de un día hábil.',
      'm.project.name': 'Nombre *',
      'm.project.business': 'Nombre del negocio',
      'm.project.email': 'Correo electrónico *',
      'm.project.phone': 'Teléfono',
      'm.project.website': 'Sitio web actual',
      'm.project.industry': 'Industria',
      'm.project.need': '¿Qué necesitas?',
      'm.project.budget': 'Presupuesto',
      'm.project.timeline': 'Cronograma',
      'm.project.details': 'Cuéntanos sobre tu proyecto *',
      'm.project.submit': 'Obtén mi plan de proyecto →',
      'm.project.note': 'Al enviar, aceptas ser contactado sobre tu proyecto. Sin spam, sin listas — jamás.',
      'm.project.success': 'Solicitud recibida.',
      'm.project.thank': 'Gracias por contactar a PTG Sites. Hemos recibido tu solicitud de proyecto y revisaremos tus requisitos — espera noticias dentro de un día hábil.',
      'm.project.back': 'Volver al sitio',

      'm.book.title': 'Reserva una llamada de descubrimiento',
      'm.book.sub': 'Una conversación relajada de 20 minutos sobre tu negocio y lo que necesitas en línea. Sin presión, sin pitch — solo un plan.',
      'm.book.type': 'Tipo de reunión',
      'm.book.tz': 'Tu zona horaria',
      'm.book.continue': 'Continuar →',
      'm.book.back': 'Atrás',
      'm.book.summary': 'Tu llamada de descubrimiento está confirmada. Te enviaremos una invitación de calendario y un recordatorio a tu correo.',
      'm.book.confirm': 'Confirmar mi llamada →',
      'm.book.notes': '¿De qué deberíamos hablar?',
      'm.book.notesPlaceholder': 'Opcional — tu negocio, tu sitio, anything worth knowing before we talk.',

      'm.legal.title': 'Documentos legales',
    },

    current: 'en',
    init() {
      try { const v = localStorage.getItem(LS_LANG); if (v === 'es' || v === 'en') this.current = v; } catch (e) {}
      this.apply();
    },

    get isEs() { return this.current === 'es'; },

    // apply() must be safe to call repeatedly (re-renders, lang on resize, etc.)
    apply() {
      const html = document.documentElement;
      if (html) html.lang = this.isEs ? 'es' : 'en';

      // text nodes: cache the authored English the first time, then swap.
      document.querySelectorAll('[data-i18n]').forEach((el) => {
        const key = el.getAttribute('data-i18n');
        if (el.dataset.iOrig === undefined) el.dataset.iOrig = el.textContent;
        el.textContent = this.isEs ? (this.dict[key] || el.dataset.iOrig) : el.dataset.iOrig;
      });

      // HTML nodes (copy that contains inline elements/formatting).
      document.querySelectorAll('[data-i18n-html]').forEach((el) => {
        const key = el.getAttribute('data-i18n-html');
        if (el.dataset.iOrigH === undefined) el.dataset.iOrigH = el.innerHTML;
        el.innerHTML = this.isEs ? (this.dict[key] || el.dataset.iOrigH) : el.dataset.iOrigH;
      });

      // toggle chips
      document.querySelectorAll('.lang-toggle').forEach((t) => {
        t.classList.toggle('es', this.isEs);
        t.setAttribute('aria-pressed', String(this.isEs));
        t.setAttribute('aria-label', this.isEs ? 'Cambiar a English' : 'Cambiar a Español');
      });

      // any renderer that has a re-run hook
      if (window.PTGRerenderLang) window.PTGRerenderLang();
    },

    toggle() {
      this.current = this.isEs ? 'en' : 'es';
      try { localStorage.setItem(LS_LANG, this.current); } catch (e) {}
      this.apply();
      track('lang_toggle', this.current);
    },

    set(lang) {
      if (lang !== this.current) {
        this.current = lang;
        try { localStorage.setItem(LS_LANG, lang); } catch (e) {}
        this.apply();
        track('lang_toggle', lang);
      }
    }
  };

  // wire the toggle: clicking EN or ES flips the language.
  document.addEventListener('click', (e) => {
    const t = e.target.closest('.lang-toggle');
    if (!t) return;
    e.preventDefault();
    Lang.toggle();
  });

  /* ----------------------------- nav ----------------------------- */
  function initNav() {
    const nav = $('#nav');
    if (!nav) return;
    const onScroll = () => nav.classList.toggle('scrolled', window.scrollY > 40);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    const burger = $('#navBurger');
    const menu = $('#menu');
    if (burger && menu) {
      const setMenu = (open) => {
        menu.classList.toggle('open', open);
        burger.classList.toggle('open', open);
        burger.setAttribute('aria-expanded', open);
        menu.setAttribute('aria-hidden', !open);
        document.body.style.overflow = open ? 'hidden' : '';
        if (open) $$('.menu-link', menu).forEach((l, i) => { l.style.transitionDelay = (0.07 * i + 0.1) + 's'; });
      };
      burger.addEventListener('click', () => setMenu(!menu.classList.contains('open')));
      $('#menuClose') && $('#menuClose').addEventListener('click', () => setMenu(false));
      $$('.menu-link', menu).forEach((l) => l.addEventListener('click', () => setMenu(false)));
      menu.addEventListener('click', (e) => { if (e.target === menu) setMenu(false); });
    }
  }

  /* ----------------------------- marquee ----------------------------- */
  function initMarquee() {
    const track = $('#marqueeTrack');
    if (!track) return;
    track.innerHTML += track.innerHTML; // duplicate for seamless loop
  }

  /* ----------------------------- portfolio ----------------------------- */
  let activeFilter = 'All';

  function initFilters() {
    const box = $('#filters');
    if (!box) return;
    const cats = ['All'];
    projects.forEach((p) => (p.categories || []).forEach((c) => { if (!cats.includes(c)) cats.push(c); }));
    const labels = { Restaurants: 'Restaurants', Beauty: 'Beauty', 'E-Commerce': 'E-Commerce', 'Professional Services': 'Professional Services', 'Local Business': 'Local Business', Hospitality: 'Hospitality' };
    cats.sort((a, b) => (labels[a] || a).localeCompare(labels[b] || b));
    // keep All first, then stable order
    const ordered = ['All'].concat(cats.filter((c) => c !== 'All'));
    box.innerHTML = ordered.map((c) => '<button class="filter-btn' + (c === 'All' ? ' active' : '') + '" data-filter="' + c + '">' + (labels[c] || c) + '</button>').join('');
    box.addEventListener('click', (e) => {
      const b = e.target.closest('.filter-btn');
      if (!b) return;
      activeFilter = b.dataset.filter;
      $$('.filter-btn', box).forEach((x) => x.classList.toggle('active', x === b));
      renderShowcase();
      track('filter', activeFilter);
    });
  }

  function renderShowcase() {
    const box = $('#showcase');
    if (!box) return;
    const list = projects.filter((p) => p.published !== false && (activeFilter === 'All' || (p.categories || []).includes(activeFilter)));
    box.innerHTML = list.map((p, i) => {
      const flip = i % 2 === 1 ? 'reverse' : '';
      const liveUrl = p.url || p.previewUrl;
      return (
        '<article class="project-row ' + flip + '" data-slug="' + esc(p.id) + '">' +
          '<div class="project-info">' +
            '<div class="project-index">PROJECT ' + String(i + 1).padStart(2, '0') + ' — ' + esc(p.industry || '') + '</div>' +
            '<h3 class="project-name">' + esc(p.name) + '</h3>' +
            '<div class="project-meta">' + (p.services || []).slice(0, 4).map((s2) => '<span>' + esc(s2) + '</span>').join('') + '</div>' +
            '<p class="project-desc">' + esc(p.tagline || p.description || '') + '</p>' +
            '<div class="project-ctas">' +
              '<a class="btn btn-primary btn-sm" href="case-study.html?slug=' + encodeURIComponent(p.id) + '">View Case Study <span class="arr">→</span></a>' +
              (liveUrl ? '<a class="btn btn-ghost btn-sm" href="' + esc(liveUrl) + '" target="_blank" rel="noopener">Visit Website</a>' : '') +
            '</div>' +
          '</div>' +
          '<a class="project-preview live-preview" data-live-url="' + esc(p.previewUrl || '') + '" data-live-title="' + esc(p.name + ' — live preview') + '" href="case-study.html?slug=' + encodeURIComponent(p.id) + '" aria-label="View ' + esc(p.name) + ' case study">' +
            '<img src="' + esc(posterSrc(p.image)) + '" alt="' + esc(p.imageAlt || p.name) + '" loading="lazy">' +
            '<span class="lp-chip">Live Preview</span>' +
            '<div class="preview-overlay"><span class="visit">View Case Study <span class="arr">→</span></span></div>' +
          '</a>' +
        '</article>'
      );
    }).join('');
    bindReveals(box);
    initLivePreviews(box);
  }

  /* ----------------------------- services ----------------------------- */
  const svcVisuals = {
    design: 'assets/work/don-patron-sm.webp', redesign: 'assets/work/phonemark-sm.webp',
    ecommerce: 'assets/work/go-collection-sm.webp', booking: 'assets/work/cache-beauty-sm.webp',
    ordering: 'assets/work/la-cantina-sm.webp', landing: 'assets/work/go-collection-shop-sm.webp',
    maintenance: 'assets/work/phonemark-dashboard-sm.webp', custom: 'assets/work/isabelly-sm.webp'
  };

  function renderServices() {
    const box = $('#servicesList');
    if (!box) return;
    box.innerHTML = services.map((s) => {
      const feats = (s.features || []).map((f) => '<span>' + f + '</span>').join('');
      return (
        '<div class="service-row" data-svc="' + s.id + '" tabindex="0" role="button" aria-expanded="false">' +
          '<span class="s-num">' + (s.num || '') + '</span>' +
          '<div><div class="s-title">' + s.title + '</div><div class="s-blurb">' + s.blurb + '</div></div>' +
          '<span class="s-toggle">+</span>' +
          '<div class="s-detail"><p>' + s.detail + '</p><div class="service-feats">' + feats + '</div></div>' +
        '</div>'
      );
    }).join('');

    const frame = $('#svFrame');
    const caption = $('#svCaption');
    const rows = $$('.service-row', box);
    const openRow = (row, force) => {
      const isOpen = row.classList.contains('open');
      if (force === true && isOpen) return;
      if (force === false) { row.classList.remove('open'); row.setAttribute('aria-expanded', 'false'); return; }
      rows.forEach((r) => { if (r !== row) { r.classList.remove('open'); r.setAttribute('aria-expanded', 'false'); } });
      row.classList.toggle('open');
      row.setAttribute('aria-expanded', row.classList.contains('open'));
      const d = $('.s-detail', row);
      d.style.maxHeight = row.classList.contains('open') ? d.scrollHeight + 'px' : '';
      if (frame && row.classList.contains('open')) {
        const img = svcVisuals[row.dataset.svc];
        if (img) {
          $$('img', frame).forEach((im) => im.classList.remove('active'));
          let el = $('img[src="' + img + '"]', frame);
          if (!el) {
            el = document.createElement('img');
            el.src = img; el.alt = '';
            frame.appendChild(el);
          }
          requestAnimationFrame(() => el.classList.add('active'));
          caption.textContent = row.dataset.svc ? row.querySelector('.s-title').textContent : '';
        }
      }
    };
    rows.forEach((row) => {
      row.addEventListener('click', () => openRow(row));
      row.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openRow(row); } });
    });
    if (rows[0]) openRow(rows[0]);
  }

  /* ----------------------------- process ----------------------------- */
  let processST = null;
  function renderProcess() {
    const track = $('#processTrack');
    if (!track) return;
    if (!track.dataset.rendered) {
      track.innerHTML = process.map((p) =>
        '<div class="process-step"><div class="p-num">' + p.num + '</div><h3>' + p.title + '</h3><p>' + p.blurb + '</p></div>'
      ).join('') + '<div class="process-step"><div class="p-num">→</div><h3>Let\'s Talk</h3><p><a href="#" data-open-modal="project" style="color:var(--accent);text-decoration:underline;text-underline-offset:3px">Start your project</a> and we\'ll take it from step one.</p></div>';
      track.dataset.rendered = '1';
    }
    setupProcessPin();
  }

  function setupProcessPin() {
    const track = $('#processTrack');
    const pin = $('#processPin');
    if (processST) { processST.kill(); processST = null; }
    // If the pinned horizontal scroll can't run (small screens, reduced motion,
    // GSAP unavailable), fall back to a native swipeable row instead of
    // clipping steps 3–7 off the edge of the screen.
    if (!track || !pin) return;
    if (reduced || window.innerWidth < 768 || !hasGsap) {
      pin.classList.add('process-static');
      if (hasGsap) gsap.set(track, { clearProps: 'transform' });
      else track.style.transform = '';
      return;
    }
    pin.classList.remove('process-static');
    const dist = () => track.scrollWidth - Math.min(window.innerWidth, 1440) + 120;
    processST = gsap.to(track, {
      x: () => -dist(),
      ease: 'none',
      scrollTrigger: {
        trigger: pin, start: 'top top', end: () => '+=' + dist(),
        scrub: 1, pin: true, anticipatePin: 1, invalidateOnRefresh: true
      }
    }).scrollTrigger;
  }

  let resizeT = null;
  window.addEventListener('resize', () => {
    clearTimeout(resizeT);
    resizeT = setTimeout(() => { setupProcessPin(); if (hasGsap) ScrollTrigger.refresh(); }, 220);
  });

  /* ----------------------------- pricing ----------------------------- */
  function money(n) { return n.toLocaleString('en-US'); }

  function renderPricing() {
    const box = $('#priceGrid');
    if (!box) return;
    box.innerHTML = pricing.map((p) => {
      const amt = p.price != null
        ? '<div class="price-amt"><span class="cur">$</span>' + money(p.price) + '</div>'
        : '<div class="price-amt" style="font-size:clamp(2rem,3.4vw,2.8rem)">Custom Quote</div>';
      const feats = (p.features || []).map((f) => '<li>' + f + '</li>').join('');
      return (
        '<div class="price-card' + (p.popular ? ' popular' : '') + '">' +
          (p.popular ? '<span class="popular-badge">Most Popular</span>' : '') +
          '<h3>' + p.name + '</h3>' +
          '<p class="price-tagline">' + p.tagline + '</p>' +
          amt +
          '<div class="price-per">Starting price · ' + p.unit + '</div>' +
          '<ul class="price-feats">' + feats + '</ul>' +
          '<a class="btn ' + (p.popular ? 'btn-paper' : 'btn-outline-paper') + ' btn-block" href="#" data-price="' + p.id + '" data-open-modal="project">' + p.cta + ' <span class="arr">→</span></a>' +
        '</div>'
      );
    }).join('');
  }

  /* ----------------------------- maintenance plans ----------------------------- */
  let billing = 'monthly';

  function renderPlans() {
    const box = $('#planGrid');
    if (!box) return;
    box.innerHTML = plans.map((p) => {
      const amt = billing === 'monthly' ? p.monthly : p.yearly;
      const per = billing === 'monthly' ? '/month' : '/year';
      const billed = billing === 'yearly' ? 'Billed annually' : 'Cancel anytime';
      const feats = (p.features || []).map((f) => '<li>' + f + '</li>').join('');
      return (
        '<div class="plan-card' + (p.popular ? ' popular' : '') + '">' +
          '<h3 class="plan-name">' + p.name + '</h3>' +
          '<p class="plan-tagline">' + p.tagline + '</p>' +
          '<div class="plan-price"><span class="amt">$' + money(amt) + '</span><span class="per">' + per + '</span></div>' +
          '<div class="billed" style="color:var(--ink-faint);font-size:12.5px">' + billed + '</div>' +
          '<ul class="plan-feats">' + feats + '</ul>' +
          '<a class="btn btn-primary btn-block" href="checkout.html?plan=' + p.id + '&billing=' + billing + '" data-plan="' + p.id + '">' + p.cta + ' <span class="arr">→</span></a>' +
        '</div>'
      );
    }).join('');
  }

  function initBilling() {
    const toggle = $('#billingToggle');
    if (!toggle) return;
    toggle.addEventListener('click', (e) => {
      const b = e.target.closest('[data-billing]');
      if (!b) return;
      billing = b.dataset.billing;
      $$('button', toggle).forEach((x) => x.classList.toggle('active', x === b));
      toggle.classList.toggle('year', billing === 'yearly');
      renderPlans();
      track('billing_toggle', billing);
    });
  }

  /* ----------------------------- proof + journal ----------------------------- */
  function renderProof() {
    const box = $('#proofGrid');
    if (!box) return;
    const feats = projects.filter((p) => p.featured && p.published !== false).slice(0, 3);
    box.innerHTML = feats.map((p) =>
      '<a class="proof-proj" href="case-study.html?slug=' + encodeURIComponent(p.id) + '">' +
        '<div class="pp-industry">' + p.industry + '</div>' +
        '<h3>' + p.name + '</h3>' +
        '<p>' + p.tagline + '</p>' +
      '</a>'
    ).join('');
  }

  function renderJournal() {
    const box = $('#journalGrid');
    if (!box) return;
    if (!journal.length) { if (box) box.style.display = 'none'; return; }
    if (box) {
      box.style.cssText = 'display:grid;grid-template-columns:repeat(2,1fr);gap:1px;background:var(--line);border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;';
      box.innerHTML = journal.slice(0, 4).map((j) =>
        '<a class="proof-proj" style="background:var(--bg-2)" href="journal/' + j.slug + '.html">' +
          '<div class="pp-industry">' + j.topic + ' · ' + j.readTime + '</div>' +
          '<h3 style="text-transform:none;letter-spacing:-0.02em">' + j.title + '</h3>' +
          '<p>' + j.excerpt + '</p>' +
        '</a>'
      ).join('');
    }
  }

  /* ----------------------------- FAQ ----------------------------- */
  function renderFaq() {
    const box = $('#faqList');
    if (!box) return;
    box.innerHTML = faqs.map((f) =>
      '<div class="faq-item">' +
        '<button class="faq-q" aria-expanded="false">' + f.q + '<span class="f-ico">+</span></button>' +
        '<div class="faq-a"><p>' + f.a + '</p></div>' +
      '</div>'
    ).join('');
    $$('.faq-item', box).forEach((item) => {
      const q = $('.faq-q', item);
      q.addEventListener('click', () => {
        const open = item.classList.contains('open');
        $$('.faq-item.open', box).forEach((o) => {
          o.classList.remove('open');
          $('.faq-q', o).setAttribute('aria-expanded', 'false');
          $('.faq-a', o).style.maxHeight = '';
        });
        if (!open) {
          item.classList.add('open');
          q.setAttribute('aria-expanded', 'true');
          const a = $('.faq-a', item);
          a.style.maxHeight = a.scrollHeight + 'px';
        }
      });
    });
  }

  /* ----------------------------- forms ----------------------------- */
  function fillOptions() {
    const fo = S.formOptions || {};
    const fill = (sel, arr) => {
      const el = $(sel);
      if (el && arr) el.innerHTML = arr.map((o) => '<option value="' + o + '">' + o + '</option>').join('');
    };
    fill('#pf-industry', fo.industries);
    fill('#pf-need', fo.needs);
    fill('#pf-budget', fo.budgets);
    fill('#pf-timeline', fo.timelines);
    fill('#bk-type', (SET.booking && SET.booking.meetingTypes) || ['Discovery Call', 'Website Consultation', 'Maintenance Check-In']);
    const tz = $('#bk-tz');
    if (tz) {
      const zones = [
        'America/New_York', 'America/Chicago', 'America/Denver', 'America/Los_Angeles',
        'America/Phoenix', 'America/Anchorage', 'America/Toronto', 'America/Mexico_City',
        'America/Sao_Paulo', 'Europe/London', 'Europe/Madrid', 'Europe/Paris', 'Europe/Berlin'
      ];
      const now = Intl.DateTimeFormat().resolvedOptions().timeZone || 'America/New_York';
      const all = zones.includes(now) ? zones : [now].concat(zones);
      tz.innerHTML = all.map((z) => '<option value="' + z + '"' + (z === now ? ' selected' : '') + '>' + z.replace('_', ' ') + '</option>').join('');
    }
  }

  function leadQuality(f) {
    const hotBudgets = ['$2,500–$5,000', '$5,000–$10,000', '$10,000+'];
    const hot = hotBudgets.includes(f.budget) && f.timeline === 'ASAP';
    if (hot) return 'HOT';
    if (hotBudgets.includes(f.budget) || f.budget === '$1,000–$2,500') return 'WARM';
    return 'NURTURE';
  }

  function initProjectForm() {
    const form = $('#projectForm');
    if (!form) return;
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const spam = spamGuard(form);
      if (spam) { alert(spam); return; }
      const data = Object.fromEntries(new FormData(form).entries());
      delete data.pt_hp;
      if (!data.name || !data.email || !data.details) {
        form.querySelectorAll('[required]').forEach((el) => { if (!el.value) el.style.borderColor = 'var(--danger)'; });
        return;
      }
      data.quality = leadQuality(data);
      data.created = new Date().toISOString();
      const leads = store.get('ptg_leads', []);
      leads.unshift(data);
      store.set('ptg_leads', leads);
      track('lead_submit', data.quality, { budget: data.budget, need: data.need });
      if (SET.backend && SET.backend.url) {
        try { fetch(SET.backend.url, { method: 'POST', mode: 'no-cors', headers: { 'Content-Type': 'text/plain' }, body: JSON.stringify({ type: 'lead', ...data }) }); } catch (err) {}
      }
      const view = $('.form-view', form.closest('.modal-card'));
      const ok = $('#projectSuccess');
      if (view && ok) { view.style.display = 'none'; ok.classList.add('show'); }
      form.reset();
    });
  }

  /* ----------------------------- booking wizard ----------------------------- */
  function initBooking() {
    const modal = $('#modal-book');
    if (!modal) return;
    if (SET.booking && SET.booking.calendlyUrl) {
      document.querySelectorAll('[data-open-modal="book"]').forEach((b) => {
        b.addEventListener('click', () => { window.open(SET.booking.calendlyUrl, '_blank'); });
      });
      return;
    }
    const steps = $$('.booking-step', modal);
    const goStep = (n) => {
      steps.forEach((s) => s.classList.toggle('active', +s.dataset.step === n));
      if (n === 3) updateSummary();
    };
    let day = null, time = null;

    const daysBox = $('#bkDays');
    const timesBox = $('#bkTimes');

    function buildDays() {
      const start = new Date();
      start.setDate(start.getDate() + 1);
      let html = '';
      for (let i = 0; i < 7; i++) {
        const d = new Date(start);
        d.setDate(start.getDate() + i);
        const dow = d.toLocaleDateString('en-US', { weekday: 'short' });
        const num = d.getDate();
        html += '<button class="day-cell" data-d="' + d.toISOString().slice(0, 10) + '" data-t="' + num + '"><small>' + dow + '</small>' + num + '</button>';
      }
      daysBox.innerHTML = html;
      $$('.day-cell', daysBox).forEach((c) => c.addEventListener('click', () => {
        $$('.day-cell', daysBox).forEach((x) => x.classList.remove('selected'));
        c.classList.add('selected');
        day = c.dataset.d;
        buildTimes(day);
      }));
    }

    function buildTimes(dayStr) {
      const now = new Date();
      const isToday = dayStr === new Date().toISOString().slice(0, 10);
      const slots = [];
      for (let h = 9; h <= 16; h += 0.5) {
        const t = new Date(dayStr + 'T' + String(Math.floor(h)).padStart(2, '0') + ':' + (h % 1 ? '30' : '00'));
        if (isToday && t <= now) continue;
        slots.push(t);
      }
      timesBox.innerHTML = slots.map((t) =>
        '<button class="time-cell" data-t="' + t.toISOString() + '">' + t.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }) + '</button>'
      ).join('');
      $$('.time-cell', timesBox).forEach((c) => c.addEventListener('click', () => {
        $$('.time-cell', timesBox).forEach((x) => x.classList.remove('selected'));
        c.classList.add('selected');
        time = c.dataset.t;
        $('#bkTimeNext').disabled = false;
      }));
    }

    function updateSummary() {
      const type = $('#bk-type').value;
      const tz = $('#bk-tz').value;
      const nice = time ? new Date(time).toLocaleString('en-US', { weekday: 'long', month: 'long', day: 'numeric', hour: 'numeric', minute: '2-digit', timeZone: tz }) : '';
      $('#bookSummary').textContent = type + ' — ' + nice + ' (' + tz.replace('_', ' ') + '). We\'ll send a calendar invite and reminder to your email.';
    }

    $$('[data-bk-next]', modal).forEach((b) => b.addEventListener('click', () => {
      const cur = +$('.booking-step.active', modal).dataset.step;
      if (cur === 2 && !time) return;
      goStep(cur + 1);
    }));
    $$('[data-bk-back]', modal).forEach((b) => b.addEventListener('click', () => {
      goStep(+$('.booking-step.active', modal).dataset.step - 1);
    }));

    $('#bkSubmit').addEventListener('click', () => {
      const bookForm = $('#modal-book');
      const spam = bookForm ? spamGuard(bookForm) : null;
      if (spam) { alert(spam); return; }
      const name = $('#bk-name').value.trim();
      const email = $('#bk-email').value.trim();
      if (!name || !email) { if (!name) $('#bk-name').style.borderColor = 'var(--danger)'; if (!email) $('#bk-email').style.borderColor = 'var(--danger)'; return; }
      const appt = {
        type: $('#bk-type').value, tz: $('#bk-tz').value,
        day: day, time: time, name: name, email: email,
        notes: $('#bk-notes').value, created: new Date().toISOString()
      };
      const apps = store.get('ptg_appointments', []);
      apps.unshift(appt);
      store.set('ptg_appointments', apps);
      track('booking', appt.type);
      if (SET.backend && SET.backend.url) {
        try { fetch(SET.backend.url, { method: 'POST', mode: 'no-cors', headers: { 'Content-Type': 'text/plain' }, body: JSON.stringify({ type: 'appointment', ...appt }) }); } catch (err) {}
      }
      const view = $('.form-view', modal.querySelector('.modal-card'));
      const ok = $('#bookSuccess');
      if (view && ok) { view.style.display = 'none'; ok.classList.add('show'); updateSummary(); }
    });

    // reset on open
    document.addEventListener('click', (e) => {
      const opener = e.target.closest('[data-open-modal="book"]');
      if (opener) {
        setTimeout(() => {
          const view = $('.form-view', modal.querySelector('.modal-card'));
          const ok = $('#bookSuccess');
          if (view && ok) { view.style.display = ''; ok.classList.remove('show'); }
          goStep(1);
          day = null; time = null;
          $('#bkTimeNext').disabled = true;
          buildDays();
        }, 50);
      }
    });
    buildDays();
  }

  /* ----------------------------- modals ----------------------------- */
  function initModals() {
    $$('.modal').forEach((m) => {
      const close = () => {
        m.classList.remove('open');
        m.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
      };
      $('[data-close-modal]', m) && $('[data-close-modal]', m).addEventListener('click', close);
      m.addEventListener('click', (e) => { if (e.target === m) close(); });
      document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && m.classList.contains('open')) close(); });
    });
    document.addEventListener('click', (e) => {
      const opener = e.target.closest('[data-open-modal]');
      if (!opener) return;
      const target = $('#modal-' + opener.dataset.openModal);
      if (!target) return;
      e.preventDefault();
      target.classList.add('open');
      target.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
      track('modal_open', opener.dataset.openModal);
      // opener-driven prefill (e.g. the custom-budget CTA)
      const prefill = (sel, val) => { const f = $(sel, target); if (f && val) f.value = val; };
      prefill('#pf-need', opener.dataset.prefillNeed);
      prefill('#pf-budget', opener.dataset.prefillBudget);
      if (opener.dataset.prefillMsg) {
        const t = $('#pf-details', target);
        if (t && !t.value) t.value = opener.dataset.prefillMsg;
      }
      setTimeout(() => { const f = $('input, select, textarea', target); f && f.focus(); }, 120);
    });
  }

  /* ----------------------------- legal ----------------------------- */
  // apply the lang dict to the hero + static copy after first render so
  // they also flip on toggle (static sections aren't re-rendered by the
  // dynamic-renderer hook above).
  function applyStaticLang() {
    if (!Lang.isEs) return;
    const map = {
      '.hero-kicker': 'hero.eyebrow',
      '.hero-title': null, /* keep the hero headline in English — it's the brand voice on both langs; ES visitors still get it */
      '.hero-sub': 'hero.cta2',
      '.hero-ctas .btn-primary': 'hero.cta1',
      '.hero-ctas .btn-ghost': 'hero.cta2',
      '.hero-micro': 'hero.micro',
      '.hero-scroll': 'hero.scroll',
      '#finalTitle .serif-accent': null, // leave the accent as-is
      '.final-sub': 'final.sub',
      '.proof-quote': 'proof.q',
      '.keep-inner h3': 'keep.h',
      '.keep-inner p': 'keep.p',
      '.keep-inner a': 'keep.view',
      '.bad-verdict h3': 'bad.verdict',
      '.bad-verdict .btn-primary': 'bad.build',
      '.budget-card .btn-primary': 'budget.run',
    };
    Object.entries(map).forEach(([sel, key]) => {
      if (!key) return;
      const els = $$(sel);
      els.forEach(el => {
        if (el.dataset.iOrig === undefined) el.dataset.iOrig = el.textContent;
        el.textContent = Lang.dict[key] || el.dataset.iOrig;
      });
    });
  }
  Lang.apply = (function (origApply) {
    return function () {
      origApply.call(this);
      applyStaticLang();
    };
  })(Lang.apply);

  /* ----------------------------- legal ----------------------------- */
  function initLegal() {
    const docs = {
      Privacy: '<p>PTG Sites collects only the information you choose to share with us through our forms — your name, business, contact details and project details — to respond to your enquiry and manage any ongoing relationship. We never sell your information, and we never share it except as needed to deliver the services you request (for example, passing your details to our payment processor at checkout).</p>',
      Terms: '<p>By using ptgsites.com you agree that all project work is governed by the written agreement provided before work begins. Estimates and pricing displayed on this site are starting points; final quotes are provided in writing. All content on this website is the property of Pinnacle Tech Group Sites unless otherwise noted.</p>',
      'Refund Policy': '<p>Website projects are billed in milestones, and each milestone payment covers work already completed and delivered. Once design work begins, that portion is non-refundable. If we cannot deliver the agreed scope, you are entitled to a refund for undelivered milestones. Maintenance subscriptions can be cancelled at any time and billing stops at the end of the current period.</p>',
      'Maintenance Agreement': '<p>PTG maintenance plans cover the services listed on the plan you choose: hosting, monitoring, updates, security, content changes and support within stated limits. Your website, content, domain and accounts remain yours. You may cancel at any time; upon cancellation we hand over everything you need to take your website with you. PTG is not liable for third-party services, downtime outside our control, or content you provide.</p>'
    };
    document.addEventListener('click', (e) => {
      const a = e.target.closest('[data-open-modal="legal"]');
      if (!a) return;
      e.preventDefault();
      const title = a.textContent.trim();
      const body = docs[title] || docs.Privacy;
      const t = $('#legalTitle');
      const b = $('#legalBody');
      if (t) t.textContent = title;
      if (b) b.innerHTML = body;
    });
  }

  /* ----------------------------- footer bits ----------------------------- */
  function initFooter() {
    const y = $('#year');
    if (y) y.textContent = new Date().getFullYear();
    const ph = $('#menuPhone');
    if (ph) ph.textContent = 'Call: ' + (SET.phone || '');
    const soc = $('#socials');
    if (soc && SET.socials) {
      const icons = { instagram: 'IG', facebook: 'FB', linkedin: 'IN' };
      soc.innerHTML = Object.keys(SET.socials).filter((k) => SET.socials[k]).map((k) =>
        '<a href="' + SET.socials[k] + '" target="_blank" rel="noopener" aria-label="' + k + '">' + (icons[k] || k[0].toUpperCase()) + '</a>'
      ).join('');
    }
  }

  /* ----------------------------- reveal system ----------------------------- */
  let io = null;
  function bindReveals(root) {
    const els = $$('.reveal, [data-mask]', root);
    if (reduced) { els.forEach((el) => el.classList.add('in')); return; }
    if (!io) {
      io = new IntersectionObserver((entries) => {
        entries.forEach((en) => { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } });
      }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });
    }
    els.forEach((el) => io.observe(el));
  }

  function initTitleReveals() {
    if (!hasGsap) {
      $$('.display-title .line > span, .final-title .line > span').forEach((el) => { el.style.transform = 'none'; });
      return;
    }
    $$('.display-title, .final-title').forEach((title) => {
      const spans = $$('.line > span', title);
      if (!spans.length) return;
      gsap.fromTo(spans, { yPercent: 112 }, {
        yPercent: 0, duration: 1.1, ease: 'power4.out', stagger: 0.08,
        scrollTrigger: { trigger: title, start: 'top 86%', once: true }
      });
    });
  }

  /* ----------------------------- score ring ----------------------------- */
  function initScore() {
    const ring = $('#scoreRing');
    if (!ring) return;
    const note = document.createElement('p');
    note.style.cssText = 'text-align:center;color:var(--ink-faint);font-size:12px;margin-top:18px;letter-spacing:0.04em';
    note.textContent = 'Illustrative assessment — get your real website\'s score free.';
    const bars = $('#scoreBars');
    if (bars) bars.after(note);

    const C = 2 * Math.PI * 120;
    ring.style.strokeDasharray = C;
    ring.style.strokeDashoffset = C;

    const anim = () => {
      const num = $('#scoreNum');
      const target = 68;
      if (hasGsap) {
        const obj = { v: 0 };
        gsap.to(obj, {
          v: target, duration: 1.6, ease: 'power3.out',
          onUpdate: () => {
            ring.style.strokeDashoffset = C * (1 - obj.v / 100);
            if (num) num.textContent = Math.round(obj.v);
          }
        });
        $$('.sb-fill').forEach((f) => {
          gsap.fromTo(f, { width: 0 }, { width: f.dataset.w + '%', duration: 1.2, ease: 'power3.out', delay: 0.2 });
        });
      } else {
        ring.style.strokeDashoffset = C * (1 - target / 100);
        if (num) num.textContent = target;
        $$('.sb-fill').forEach((f) => { f.style.width = f.dataset.w + '%'; });
      }
    };
    if (hasGsap) {
      ScrollTrigger.create({ trigger: $('#audit'), start: 'top 70%', once: true, onEnter: anim });
    } else {
      const io2 = new IntersectionObserver((es) => { es.forEach((e) => { if (e.isIntersecting) { anim(); io2.disconnect(); } }); }, { threshold: 0.3 });
      io2.observe($('#audit'));
    }
  }

  /* ----------------------------- init ----------------------------- */
  function init() {
    Lang.init();
    injectShell();
    ensureConsentBanner();

    initNav();
    initMarquee();
    initFilters();
    renderShowcase();
    renderServices();
    renderProcess();
    renderPricing();
    renderPlans();
    initBilling();
    renderProof();
    renderJournal();
    renderFaq();
    fillOptions();
    initProjectForm();
    initBooking();
    initModals();
    initLegal();
    initFooter();
    bindReveals(document);
    initTitleReveals();
    initScore();

    // audit page hooks (present on audit.html)
    const auditForm = $('#auditForm');
    if (auditForm) initAuditForm(auditForm);

    initLenis();
    initSmoothAnchors();
    initLivePreviews(document);
    initSpamGuards();
    runLoader();

    // expose a rerender hook so dynamic sections flip when the visitor
    // changes language after the homepage has rendered (the static copy is
    // handled by Lang.apply -> applyStaticLang).
    window.PTGRerenderLang = () => {
      renderServices();
      renderProcess();
      renderPricing();
      renderPlans();
      renderProof();
      renderJournal();
      renderFaq();
      initFooter();
    };
  }

  function initSpamGuards() {
    ['#projectForm', '#modal-book', '#auditForm'].forEach((sel) => { const f = $(sel); if (f) armSpamGuard(f); });
    document.addEventListener('click', (e) => {
      const b = e.target.closest('[data-open-consent]');
      if (!b) return;
      e.preventDefault();
      store.set('ptg_consent', null);
      ensureConsentBanner();
    });
  }

  const posterSrc = (src) => String(src || '').replace('.webp', '-sm.webp');

  /* ----------------------------- audit page ----------------------------- */
  function initAuditForm(form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const spam = spamGuard(form);
      if (spam) { alert(spam); return; }
      const data = Object.fromEntries(new FormData(form).entries());
      delete data.pt_hp;
      if (!data.url || !data.name || !data.email) return;
      data.created = new Date().toISOString();
      const audits = store.get('ptg_audits', []);
      audits.unshift(data);
      store.set('ptg_audits', audits);
      track('audit_submit', data.url);
      if (SET.backend && SET.backend.url) {
        try { fetch(SET.backend.url, { method: 'POST', mode: 'no-cors', headers: { 'Content-Type': 'text/plain' }, body: JSON.stringify({ type: 'audit', ...data }) }); } catch (err) {}
      }
      const card = form.closest('.audit-card') || form.parentElement;
      const ok = $('#auditSuccess');
      if (card && ok) { card.style.display = 'none'; ok.classList.add('show'); }
      form.reset();
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();