/* ============================================================
   PTG SITES — DATA LAYER
   Everything the site renders lives here (or in admin overrides).
   Edit values below, or use the admin dashboard (admin.html).
   Admin changes persist in the browser and can be exported.
   ============================================================ */
window.PTG = window.PTG || {};

PTG.settings = {
  name: "PTG Sites",
  legalName: "Pinnacle Tech Group Sites",
  tagline: "Websites built to make businesses look better, work better, and grow.",
  domain: "https://ptgsites.com",
  email: "hello@ptgsites.com",          // <-- confirm
  phone: "(617) 555-0142",              // <-- confirm / change
  phoneHref: "tel:+16175550142",
  city: "Boston",
  region: "Massachusetts",
  serviceArea: "Boston · Greater Boston · All of Massachusetts · Everywhere",
  socials: {
    instagram: "https://instagram.com/ptgsites",  // <-- confirm handle
    facebook: "https://facebook.com/ptgsites",    // <-- confirm page
    linkedin: "https://linkedin.com/company/ptgsites" // <-- confirm page
  },
  booking: {
    // Optional Calendly / scheduling link. When empty, the on-site booking
    // modal stores the appointment and emails it via the optional backend.
    calendlyUrl: "",
    timezone: "America/New_York",
    meetingTypes: ["Discovery Call", "Website Consultation", "Maintenance Check-In"]
  },
  stripe: {
    /* HOW TO CONNECT YOUR STRIPE (recurring monthly/yearly billing):
       1. In the Stripe Dashboard create one Product per plan
          (PTG Care / PTG Grow / PTG Pro) with TWO recurring Prices each:
          a monthly price and a yearly price.
       2. For each price, click "Payment link" → create one. Payment links
          are hosted Stripe checkout pages — no server, no keys in code.
       3. Set each link's after-payment redirect to:
              https://ptgsites.com/welcome.html?plan=care&billing=monthly
          (match plan/billing per link).
       4. Paste the four link URLs below (and in Admin → Pricing, which
          overrides these). Checkout then redirects to real Stripe billing.
       5. Optional: enable the Stripe Customer Portal and paste its share
          link into billingPortalUrl so clients can manage cards/invoices. */
    publishableKey: "",
    paymentLinks: {
      care: { monthly: "", yearly: "" },
      grow: { monthly: "", yearly: "" },
      pro:  { monthly: "", yearly: "" }
    },
    billingPortalUrl: ""
  },
  backend: {
    // Optional Google Apps Script endpoint (see apps-script/Code.gs).
    // When empty, leads/requests are stored locally in the browser.
    url: ""
  },
  analytics: {
    enabled: true,        // lightweight local analytics (admin dashboard reads it)
    trackEvents: true
  }
};

/* ------------------------- PORTFOLIO ------------------------- */
PTG.projects = [
  {
    id: "don-patron",
    slug: "don-patron",
    name: "Don Patron",
    client: "Don Patron Mexican Grill & Cantina",
    industry: "Restaurant & Cantina",
    categories: ["Restaurants", "Hospitality"],
    year: "2026",
    location: "Bristol, RI",
    featured: true,
    published: true,
    tagline: "A full digital presence for a family-run Mexican grill & cantina.",
    description: "A cinematic single-page experience with a complete menu browser, on-site pickup ordering, reservations and catering — built to run the front of house and get tables and orders moving.",
    challenge: "A restaurant that lives on reviews and word of mouth had a website that didn't sell the food. No menu to browse, no way to order, reservations meant a phone call — and every minute a guest spent hunting for a number was a minute they could have spent at another taquería.",
    approach: "We rebuilt the entire presence around the two things that make a restaurant money: the menu and the phone. Real dishes, real prices, real photography — and a path to order or reserve in seconds.",
    solution: [
      { title: "Full menu as a living system", detail: "17 sections and 56 dishes with real prices in a searchable, bilingual browser — the kitchen's actual menu book, brought online." },
      { title: "On-site pickup ordering", detail: "A cart and checkout flow built into the site — no third-party ordering app standing between the guest and the kitchen." },
      { title: "Reservations wizard", detail: "Find a table, add your details, done. Staff confirm from a live dashboard with automatic guest emails." },
      { title: "Catering & events intake", detail: "A full catering form with headcount, date, budget and service type, wired to the same dashboard." },
      { title: "Live open/closed status", detail: "Real hours driving real status — visitors always know if the kitchen is taking orders right now." },
      { title: "Bilingual EN / ES", detail: "The entire site translates live, because the menu's best customers speak both." }
    ],
    services: ["Web Design", "Menu System", "Pickup Ordering", "Reservations", "Catering Intake", "EN / ES"],
    image: "assets/work/don-patron.webp",
    imageAlt: "Don Patron Mexican Grill & Cantina website",
    url: "https://donpatronma.com",
    previewUrl: "../index.html",
    result: "Designed to create a stronger digital presence and improve the customer journey — one menu, one cart and one reservation form doing the work of three separate apps."
  },
  {
    id: "cache-beauty",
    slug: "cache-beauty",
    name: "Cache Beauty Spa",
    client: "Cache Beauty Spa",
    industry: "Nail Salon & Beauty Studio",
    categories: ["Beauty", "Local Business"],
    year: "2026",
    location: "East Boston, MA",
    featured: true,
    published: true,
    tagline: "A booking-first website for a neighborhood beauty studio.",
    description: "An elevated studio site with a real service menu, real prices and a booking request flow that turns browsers into booked appointments.",
    challenge: "A beloved neighborhood studio — 4.6★ on Google — ran on Instagram DMs and phone calls. There was no single place a new client could see services, understand pricing, or ask for the appointment they wanted.",
    approach: "We built the site around the booking. Services with honest prices and durations, a two-step request flow, and a calm, editorial look that matched the studio's actual vibe.",
    solution: [
      { title: "Service catalog with real pricing", detail: "Head spa, pedi spa, facials, full packages — every service priced and timed from the studio's own flyer." },
      { title: "Two-step booking request", detail: "Choose service → date & time → details. The studio confirms by phone or text; guests always know where they stand." },
      { title: "Bilingual EN / ES", detail: "The whole site translates live — East Boston is a bilingual neighborhood and the site should be too." },
      { title: "Staff dashboard + backend", detail: "Appointments, customers and service pricing managed from a PIN-gated dashboard with automatic email notifications." },
      { title: "Studio photography", detail: "Real photos of the space and its work — the flower wall, the finishes, the details clients actually care about." }
    ],
    services: ["Web Design", "Booking System", "Service Catalog", "EN / ES", "Staff Dashboard"],
    image: "assets/work/cache-beauty.webp",
    imageAlt: "Cache Beauty Spa website",
    url: "",
    previewUrl: "../cache-beauty/index.html",
    result: "Designed to create a stronger digital presence and improve the customer journey — a clear path from discovering the studio to requesting an appointment."
  },
  {
    id: "go-collection",
    slug: "go-collection",
    name: "G O Collection",
    client: "G O Collection",
    industry: "Artisan E-Commerce",
    categories: ["E-Commerce"],
    year: "2026",
    location: "Made in Colombia",
    featured: true,
    published: true,
    tagline: "A luxury e-commerce flagship for handmade artisan goods.",
    description: "A full commerce experience — shop, product pages, cart, checkout and customer accounts — wrapped around a heritage storytelling journey that makes a customer forget Etsy exists.",
    challenge: "A thriving Etsy shop with beautiful handmade pieces had no home of its own. Every product page, every cart and every checkout happened inside someone else's marketplace, and the story behind each piece got lost in the algorithm.",
    approach: "We built a flagship store: cinematic homepage, editorial product pages, real cart and checkout, and a virtual 'museum' that takes customers from Land → Material → Hands → Loom → Object.",
    solution: [
      { title: "Full commerce system", detail: "Shop with filters, product pages with zoom, cart, guest checkout, customer accounts — the complete buying path owned end to end." },
      { title: "Heritage storytelling", detail: "A scroll-driven museum journey through five chapters that makes every purchase feel like owning a piece of the story." },
      { title: "Inventory & discount management", detail: "Real inventory with low-stock logic, discount codes, collections — managed from an admin console." },
      { title: "Bilingual EN / ES", detail: "The whole store translates live for the brand's two audiences." },
      { title: "Commerce admin dashboard", detail: "Orders, products, inventory, customers, content and settings — no developer needed to run the store." }
    ],
    services: ["E-Commerce", "Web Design", "Cart & Checkout", "Product Pages", "Storytelling", "EN / ES"],
    image: "assets/work/go-collection.webp",
    imageAlt: "G O Collection e-commerce website",
    url: "",
    previewUrl: "../go-collection/index.html",
    result: "Designed to create a stronger digital presence and improve the customer journey — a shopping experience that leads with craft, not listings."
  },
  {
    id: "phonemark",
    slug: "phonemark",
    name: "PhoneMark",
    client: "PhoneMark",
    industry: "Phone Marketplace & Repair",
    categories: ["E-Commerce", "Professional Services"],
    year: "2026",
    location: "Leominster, MA",
    featured: false,
    published: true,
    tagline: "iPhone repair, buyback and a pre-owned marketplace — all in one place.",
    description: "The complete ecosystem for buying, selling and repairing Apple devices: on-site repairs across Massachusetts, instant buyback offers, a marketplace of certified pre-owned iPhones and a technician network — engineered and shipped to production.",
    challenge: "An iPhone repair business serving North Central MA and Greater Boston needed more than a flyer: repair bookings, buybacks, a marketplace with real listings and payments all had to live in one place — and feel as premium as the devices it sells.",
    approach: "We designed and built the entire platform: a conversion-first storefront, a marketplace with search and listings, an instant buyback flow, repair booking and a technician network — one system, one brand, shipped to production.",
    solution: [
      { title: "Repair, reimagined", detail: "On-site repairs across Leominster, Lunenburg, Fitchburg and Greater Boston — plus drop-off and mail-in from anywhere in Massachusetts, backed by a free 14-day warranty." },
      { title: "Pre-owned marketplace", detail: "Featured listings with condition, battery health and carrier filters, honest pricing and free shipping over $200 — with a 14-day hardware warranty on every device." },
      { title: "Instant buyback", detail: "A sell-us-your-iPhone flow with real cash offers in minutes — condition-graded quotes and fast payment." },
      { title: "Repair booking & quoting", detail: "Get-a-quote intake for screens, batteries, charging ports and software issues, routed to the right technician." },
      { title: "Technician network", detail: "A vetted Find-a-Tech directory with ratings and reviews — the repair side runs as a platform, not a phone tag." },
      { title: "Trust built in", detail: "4.9★ average rating, 98% satisfaction, transparent condition reports and warranty language on every listing — with structured data for search engines." }
    ],
    services: ["E-Commerce", "Marketplace", "Booking System", "Buyback Flow", "Technician Directory"],
    image: "assets/work/phonemark.webp",
    imageAlt: "PhoneMark — iPhone repair, buyback and marketplace website",
    url: "https://thephonemark.com",
    previewUrl: "https://thephonemark.com",
    result: "Designed to create a stronger digital presence and improve the customer journey — repair, buyback and marketplace in one platform that looks as premium as the devices it sells."
  },
  {
    id: "isabelly-nails",
    slug: "isabelly-nails",
    name: "Isabelly Nails",
    client: "Isabelly Nails",
    industry: "Solo Nail Artist",
    categories: ["Beauty", "Local Business"],
    year: "2026",
    location: "Malden, MA",
    featured: false,
    published: true,
    tagline: "A trilingual booking site for a solo nail artist.",
    description: "An appointment-first website for an independent nail artist — services, gallery, real client work and a request-based booking flow in three languages.",
    challenge: "A by-appointment-only artist with devoted clients needed a site that felt as considered as her work — and that could speak to a Portuguese, Spanish and English clientele without losing a single detail in translation.",
    approach: "We built a calm, gallery-led site around her real work, with a booking flow built on requests — the artist confirms every appointment herself, so nothing is ever overbooked.",
    solution: [
      { title: "Request-based booking", detail: "A five-step request flow (service → date → time → details → review). The artist confirms; the client is never told 'confirmed' before it actually is." },
      { title: "Trilingual EN / PT / ES", detail: "The full site translates live in three languages — UI, services, booking and confirmation." },
      { title: "Artist dashboard", detail: "Appointments, calendar, customers, services, availability and settings from a PIN-gated console." },
      { title: "Real portfolio work", detail: "The gallery is built from the artist's actual nail sets and reels — the work sells itself." }
    ],
    services: ["Web Design", "Booking System", "Trilingual EN / PT / ES", "Portfolio Gallery"],
    image: "assets/work/isabelly.webp",
    imageAlt: "Isabelly Nails website",
    url: "",
    previewUrl: "../isabelly-nails/index.html",
    result: "Designed to create a stronger digital presence and improve the customer journey — a booking path that fits how a solo artist actually works."
  },
  {
    id: "la-cantina",
    slug: "la-cantina",
    name: "La Cantina",
    client: "La Cantina",
    industry: "Colombian & Mexican Cantina",
    categories: ["Restaurants", "Hospitality"],
    year: "2026",
    location: "Revere, MA",
    featured: false,
    published: true,
    tagline: "A cinematic single-page presence for a late-night cantina.",
    description: "One page, one vibe: hero film, full menu, live open/closed status and click-to-call everywhere — built to turn a late-night craving into a phone call.",
    challenge: "A cantina open until 2 AM needed a site that felt alive at midnight — that showed the food, said 'we're open right now', and made calling effortless from a phone.",
    approach: "We built a single cinematic page around the three things a guest at 11 PM cares about: what the food looks like, whether the kitchen is open, and how to order.",
    solution: [
      { title: "Cinematic hero film", detail: "A slow, looping film of the signature dishes — the menu as appetite, before a single word is read." },
      { title: "Full menu", detail: "Real dishes and prices presented like a menu book, not a list of links." },
      { title: "Live open / closed status", detail: "Driven by the real 2 AM-close schedule — the status is always true, never a static claim." },
      { title: "Click-to-call everywhere", detail: "The phone number in the header, hero, every dish card and the footer. One thumb, one tap." }
    ],
    services: ["Web Design", "Menu", "Live Status", "Click-to-Call"],
    image: "assets/work/la-cantina.webp",
    imageAlt: "La Cantina website",
    url: "",
    previewUrl: "../la-cantina/index.html",
    result: "Designed to create a stronger digital presence and improve the customer journey — the whole restaurant, in one fast-loading page."
  }
];

/* ------------------------- SERVICES ------------------------- */
PTG.services = [
  {
    id: "design",
    num: "01",
    title: "Custom Website Design",
    blurb: "Websites designed around your brand and your customers — not a template with your logo dropped in.",
    detail: "Every PTG site starts from your business: your customers, your competition, your goals. We design a visual system that makes you look established on day one and builds trust before a single word is read.",
    features: ["Custom design system", "Mobile-first layout", "Copy & messaging", "Brand refinement"]
  },
  {
    id: "redesign",
    num: "02",
    title: "Website Redesign",
    blurb: "Transform an outdated website into a modern digital experience.",
    detail: "If your site was built in another era — slow, cluttered, unreadable on a phone — we rebuild it around what it should actually do: represent you well and move visitors to act.",
    features: ["Full visual rebuild", "Content restructuring", "Speed & SEO fixes", "Modern technology"]
  },
  {
    id: "ecommerce",
    num: "03",
    title: "E-Commerce",
    blurb: "Online stores designed to showcase products and make purchasing simple.",
    detail: "Product pages that sell, a cart that never fights the customer, and a checkout that feels inevitable. Built to make your products look worth their price.",
    features: ["Product catalog", "Cart & checkout", "Inventory management", "Payment integration"]
  },
  {
    id: "booking",
    num: "04",
    title: "Booking & Appointments",
    blurb: "Turn your website into a 24/7 booking system.",
    detail: "Your calendar doesn't stop at closing time. A booking flow lets customers request appointments whenever they're thinking about you — and gives you a clean dashboard to confirm them.",
    features: ["Service & price catalog", "Request / confirm flow", "Availability logic", "Staff dashboard"]
  },
  {
    id: "ordering",
    num: "05",
    title: "Online Ordering",
    blurb: "Restaurants and businesses can accept orders directly through their website where supported.",
    detail: "No third-party app standing between you and your customer. Orders go straight to your kitchen dashboard with confirmation emails for every guest.",
    features: ["Menu system", "Cart & checkout", "Kitchen dashboard", "Order notifications"]
  },
  {
    id: "landing",
    num: "06",
    title: "Landing Pages",
    blurb: "High-converting pages for campaigns, services and promotions.",
    detail: "One page, one message, one action. Built for ads, launches and promotions where every second of attention counts.",
    features: ["Focused single-message design", "Conversion copy", "A/B-ready structure", "Analytics tracking"]
  },
  {
    id: "maintenance",
    num: "07",
    title: "Website Maintenance",
    blurb: "Keep your website updated, secure, functional and looking great.",
    detail: "Your website doesn't stop needing attention when it launches. PTG maintenance keeps it updated, monitored and ready — so it's never your problem.",
    features: ["Hosting & monitoring", "Updates & security", "Content changes", "Priority support"]
  },
  {
    id: "custom",
    num: "08",
    title: "Custom Digital Experiences",
    blurb: "Need something outside the box? Build custom functionality around the business.",
    detail: "Custom tools, databases, APIs and integrations — whatever your business actually needs that a template can't do. If it's worth building, we'll build it properly.",
    features: ["Custom development", "Databases & APIs", "Integrations", "Long-term support"]
  }
];

/* ------------------------- PROCESS ------------------------- */
PTG.process = [
  { num: "01", title: "Discover", blurb: "We learn about your business, customers, competitors, goals and vision." },
  { num: "02", title: "Strategize", blurb: "We determine what your website needs to accomplish — and how it will get there." },
  { num: "03", title: "Design", blurb: "We create the visual direction and user experience around your customers." },
  { num: "04", title: "Build", blurb: "We develop the website and every piece of functionality it needs." },
  { num: "05", title: "Test", blurb: "Mobile, desktop, forms, links, speed, responsiveness and functionality." },
  { num: "06", title: "Launch", blurb: "Your new website goes live. The part where the old one starts costing you money is over." },
  { num: "07", title: "Grow", blurb: "Optional ongoing maintenance, updates and improvements as your business moves." }
];

/* ------------------------- WEBSITE PRICING ------------------------- */
PTG.pricing = [
  {
    id: "starter",
    name: "Starter",
    tagline: "For businesses that need a professional online presence.",
    price: 998,
    unit: "project",
    cta: "Start My Project",
    features: [
      "Custom website design",
      "Up to 5 pages",
      "Mobile responsive",
      "Contact forms",
      "Basic SEO",
      "Social integration",
      "Launch support"
    ]
  },
  {
    id: "professional",
    name: "Professional",
    tagline: "For businesses that need a stronger customer experience.",
    price: 1500,
    unit: "project",
    cta: "Build My Website",
    popular: true,
    features: [
      "Everything in Starter",
      "Additional pages",
      "Advanced design",
      "Booking functionality",
      "Custom integrations",
      "Enhanced SEO",
      "Conversion optimization"
    ]
  },
  {
    id: "custom",
    name: "Maximum",
    tagline: "The fully-loaded build — e-commerce, ordering, integrations, the works.",
    price: 2500,
    unit: "project",
    cta: "Go Maximum",
    features: [
      "E-commerce",
      "Online ordering",
      "Advanced booking",
      "Custom databases",
      "APIs & integrations",
      "Custom functionality",
      "Priority build schedule"
    ]
  }
];

/* ------------------------- MAINTENANCE PLANS ------------------------- */
PTG.plans = [
  {
    id: "care",
    name: "PTG Care",
    tagline: "Keep your website online, secure and looked after.",
    monthly: 75,
    yearly: 750,
    currency: "USD",
    cta: "Start Care Plan",
    features: [
      "Website hosting",
      "Website monitoring",
      "Basic updates",
      "Security monitoring",
      "Minor content changes",
      "Technical support",
      "Monthly website check"
    ]
  },
  {
    id: "grow",
    name: "PTG Grow",
    tagline: "For businesses that want the website working harder.",
    monthly: 99,
    yearly: 990,
    currency: "USD",
    cta: "Start Grow Plan",
    popular: true,
    features: [
      "Everything in PTG Care",
      "More content updates",
      "Performance monitoring",
      "SEO health checks",
      "Conversion improvements",
      "Priority support",
      "Monthly optimization"
    ]
  },
  {
    id: "pro",
    name: "PTG Pro",
    tagline: "Stripe integration, payment processing and everything managed for you.",
    monthly: 199,
    yearly: 1990,
    currency: "USD",
    cta: "Go Pro",
    features: [
      "Everything in PTG Grow",
      "Stripe integration & management",
      "Payment processing connection",
      "Advanced updates",
      "Priority requests",
      "Advanced optimization",
      "Landing page updates",
      "Analytics review",
      "Conversion optimization",
      "Strategy support"
    ]
  }
];

/* ------------------------- FAQ ------------------------- */
PTG.faqs = [
  {
    q: "How much does a website cost?",
    a: "Our website packages start at $998 for a professional custom site, $1,500 for a stronger customer experience with booking, and $2,500 for a fully-loaded maximum build. And if you have a custom budget in mind, run it by us — we scope builds around real budgets all the time. You get a clear number before we start, and the price we quote is the price you pay."
  },
  {
    q: "How long does a website take?",
    a: "Most custom websites launch in 2–4 weeks. The timeline depends on how quickly content and decisions flow — we keep a tight schedule and don't disappear between milestones. E-commerce and custom builds take longer, and we'll give you a realistic date up front."
  },
  {
    q: "Do you redesign existing websites?",
    a: "Yes — redesigns are a big part of what we do. If your current site looks dated, loads slowly, or doesn't work on phones, we rebuild it around what it should actually do: represent you well and turn visitors into customers. You keep your domain, your content and anything worth keeping."
  },
  {
    q: "Do you offer payment plans?",
    a: "Yes. Most projects are split into milestones — typically 50% to start and 50% at launch — so you're never paying for work that hasn't happened. Larger custom builds are broken into more stages."
  },
  {
    q: "Do you offer website maintenance?",
    a: "We do, and we think most businesses should have it. PTG Care, Grow and Pro plans keep your site hosted, monitored, updated, secure and supported from $75/month. Launching a website without maintenance is like opening a restaurant and never cleaning the kitchen."
  },
  {
    q: "Can you build e-commerce?",
    a: "Yes. We build complete online stores — product catalogs, cart and checkout, inventory, discounts, and payment integration — plus product pages designed to make your products look worth their price. See the G O Collection in our portfolio for the standard we hold e-commerce to."
  },
  {
    q: "Can you build booking systems?",
    a: "Yes. Booking is one of our specialties — service catalogs with real pricing, request-and-confirm flows, availability logic and staff dashboards. Our Cache Beauty Spa and Isabelly Nails projects are live examples of what that looks like in practice."
  },
  {
    q: "Can you connect online payments?",
    a: "Yes. We integrate Stripe and other major processors for one-time payments, subscriptions and recurring billing. Payments are processed securely by the provider — we never store card details on your site."
  },
  {
    q: "Do I own my website?",
    a: "Yes. Your website, your content, your domain, your accounts. When we finish, everything is in your name and we hand over full access. If you ever leave, you take the site with you — no hostage situations."
  },
  {
    q: "Can you update my website after launch?",
    a: "Yes — that's exactly what our maintenance plans are for. Content changes, updates, new pages, security and support, handled by us so you never have to touch the technical side. If you'd rather manage things yourself, we can also show you how."
  },
  {
    q: "What happens after my website launches?",
    a: "We don't disappear. We hand over documentation and access, walk you through everything, and most clients stay on a maintenance plan so the site keeps working as hard as the day it launched. If you're done after launch, that's fine too — the site is yours."
  },
  {
    q: "Do you work with businesses outside Massachusetts?",
    a: "Yes. We're based in the Boston area and work with local businesses across Massachusetts and New England — but most of our process happens online, and we build for clients anywhere. A website is a 24/7 business; we run ours the same way."
  }
];

/* ------------------------- JOURNAL ------------------------- */
PTG.journal = [
  {
    slug: "how-much-does-a-website-cost",
    title: "How Much Should a Business Website Cost?",
    excerpt: "The honest answer, the math behind it, and the traps that make cheap websites expensive.",
    topic: "Budget",
    date: "2026-09-01",
    readTime: "6 min"
  },
  {
    slug: "signs-your-website-needs-a-redesign",
    title: "Signs Your Website Needs a Redesign",
    excerpt: "If your website was built in another era, it's costing you customers. Here's how to tell.",
    topic: "Redesign",
    date: "2026-08-18",
    readTime: "5 min"
  },
  {
    slug: "how-much-does-website-maintenance-cost",
    title: "How Much Does Website Maintenance Cost?",
    excerpt: "What maintenance actually covers, what it's worth, and why $0/month websites end up expensive.",
    topic: "Maintenance",
    date: "2026-08-04",
    readTime: "6 min"
  },
  {
    slug: "why-mobile-website-design-matters",
    title: "Why Mobile Website Design Matters",
    excerpt: "Your customers live on their phones. Your website needs to act like it.",
    topic: "Mobile",
    date: "2026-07-21",
    readTime: "5 min"
  }
];

/* ------------------------- LEAD FORM OPTIONS ------------------------- */
PTG.formOptions = {
  industries: ["Restaurant", "Beauty", "Real Estate", "Contractor", "Professional Services", "E-Commerce", "Medical", "Automotive", "Hospitality", "Other"],
  needs: ["New Website", "Website Redesign", "E-Commerce", "Booking Website", "Online Ordering", "Landing Page", "Maintenance", "Other"],
  budgets: ["Under $1,000", "$1,000–$2,500", "$2,500–$5,000", "$5,000–$10,000", "$10,000+"],
  timelines: ["ASAP", "1–2 weeks", "30 days", "60 days", "Flexible"]
};