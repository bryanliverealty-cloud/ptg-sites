# PTG Sites — ptgsites.com

Premium web design studio site + client acquisition engine for **Pinnacle Tech Group Sites**.
Built as a static site (no framework, no build step) with a local-first data layer and an
optional Google Apps Script backend.

```
ptg/
├── index.html          # flagship homepage
├── case-study.html     # case studies (rendered per-project via ?slug=)
├── audit.html          # free website audit lead magnet
├── checkout.html       # maintenance plan purchase (→ Stripe Payment Links)
├── welcome.html        # post-payment welcome (Stripe redirect target)
├── portal.html         # client portal (plan, billing, support requests)
├── admin.html          # admin dashboard (first run: you create the PIN)
├── privacy.html / terms.html / refund.html / maintenance-agreement.html
├── _headers .htaccess  # security headers for Netlify-Pages / Apache
├── 404.html
├── journal/            # the PTG Journal (index + articles)
├── styles.css          # design system
├── app.js              # engine: rendering, motion, forms, analytics
├── data.js             # ALL editable content lives here (or in admin)
├── assets/work/        # real screenshots of the client sites
├── fonts/              # self-hosted fonts (Space Grotesk / Inter / Instrument Serif)
├── vendor/             # self-hosted GSAP + ScrollTrigger + Lenis
├── apps-script/        # optional backend (Code.gs — see below)
├── robots.txt
└── sitemap.xml
```

## Running it

It's plain static files. Serve the **project root** (this folder's parent — `index.html`
for Don Patron also lives there) with any static server:

```bash
cd <project root>
python3 -m http.server 5180        # or the repo's perl server: perl .freebuff/serve.pl 5180 .
```

Then open `http://localhost:5180/ptg/index.html`.

## The data model

`data.js` defines `window.PTG` — settings, projects (portfolio), services, process,
pricing, maintenance plans, FAQs, journal, and form options. The public site renders
entirely from this object.

**Admin overrides:** changes made in `admin.html` (portfolio, pricing, plans, FAQs,
settings) are saved to `localStorage` under `ptg_admin_overrides` and merged over the
static data by `app.js` on every page — so editing pricing in the admin updates the
public site instantly, no rebuild. Use **Export / Import** in the admin to move data
between browsers.

## Local-first data

Until the backend is connected, everything stores in the visitor's browser:

| Collection       | localStorage key      | Written by                          |
|------------------|-----------------------|-------------------------------------|
| Leads            | `ptg_leads`           | Start Your Project form             |
| Appointments     | `ptg_appointments`    | Book A Call wizard                  |
| Audits           | `ptg_audits`          | audit.html                          |
| Orders (clients) | `ptg_orders`          | checkout.html / admin client form   |
| Requests         | `ptg_requests`        | portal.html support form            |
| Events (analytics)| `ptg_events`          | automatic (pageviews, CTA clicks, conversions) |

The admin dashboard reads all of these for MRR, client lists, lead qualification
(HOT / WARM / NURTURE) and analytics.

## Connecting Stripe (real recurring billing — no server needed)

The site bills through **Stripe Payment Links**: hosted Stripe checkout pages that
handle cards, retries, failed-payment emails and invoices natively. Card data never
touches this website.

1. Stripe Dashboard → **Product Catalog** → create a product per plan
   (PTG Care / Grow / Pro) with a **monthly** and a **yearly** recurring price.
2. For each price: **Payment Links** → create a link.
3. In each link's settings, set **After payment → redirect** to
   `https://ptgsites.com/welcome.html?plan=care&billing=monthly`
   (adjust plan/billing per link). Optionally enable `Stripe email receipts`.
4. Paste the 6 links into **Admin → Pricing** (per-plan fields) or into
   `data.js → settings.stripe.paymentLinks`.
5. Client self-service (update card, invoices, cancel): enable **Stripe Customer
   Portal**, create a share link, paste into **Admin → Settings → Customer Portal**.
   The client portal's “Manage Billing” button uses it.
6. Deploy the Apps Script backend (`apps-script/Code.gs`) if you also want every
   purchase emailed to you.

Before: `checkout.html` collects business details → creates a PENDING order →
redirects to Stripe. After payment Stripe lands on `welcome.html`, which marks the
order ACTIVE and shows onboarding. Until links are configured, checkout runs in demo
mode so you can test the full flow.

## Security posture

- **Admin PIN** — no default PIN ships. On first run you create one; only a salted
  SHA-256 hash is stored in that browser. 5 failed attempts lock the form with an
  escalating cooldown; sessions expire after 30 idle minutes. Client-side auth is
  convenience-grade: it protects local demo data only — before real client data
  lives here, put auth server-side (Supabase Auth / Apps Script) and move storage
  off localStorage.
- **XSS** — every admin-editable string is HTML-escaped at render time (`esc()`);
  form honeypots + time-traps + per-form throttling deter spam bots.
- **Headers** — `Content-Security-Policy`, `X-Frame-Options: SAMEORIGIN`,
  `nosniff`, `Referrer-Policy`, `Permissions-Policy` and HSTS ship via `_headers`
  (Netlify/Cloudflare Pages) and `.htaccess` (Apache). A same-amount CSP meta is
  baked into every page. Deploy `ptg/` as the web root so both apply.
- **Payments** — all card data is handled by Stripe (PCI DSS Level 1); nothing
  sensitive is stored locally. `.htaccess` blocks dotfiles and admin export files.
- **Analytics** — fully consent-gated: nothing is recorded until the visitor
  accepts (banner → `ptg_consent`), changeable anytime via “Cookie Preferences”.

## Legal

`privacy.html`, `terms.html`, `refund.html`, `maintenance-agreement.html` are
plain-English policies written for how this site actually behaves (local storage,
consent-gated analytics, Stripe-only payments, honest maintenance scope). They are
templates, not legal advice — have a Massachusetts attorney review before launch.

## Enabling the rest of the backend

1. Booking — set `PTG.settings.booking.calendlyUrl` to hand "Book A Call" to Calendly.
2. Emails + shared storage — deploy `apps-script/Code.gs` (instructions in the file)
   and set `PTG.settings.backend.url`. Every lead/appointment/audit is then emailed to
   you and appended to a spreadsheet.

## Motion

Animations use self-hosted GSAP + ScrollTrigger + Lenis. `prefers-reduced-motion` is
honored (content remains fully visible and static). To preview the full motion design
regardless of OS settings, open any page with `?motion=1`.

## Ownership & honesty rules baked in

- Portfolio only contains real client projects with real screenshots. No invented
  clients, stats or testimonials — "The Result" uses the honest default:
  *"Designed to create a stronger digital presence and improve the customer journey."*
- The audit score is explicitly labeled as an automated first-pass assessment; the
  real manual audit is delivered by email.
- Pricing and plans are editable starting points, clearly labeled.
## Live site embeds (iframes)

The homepage hero, work showcase and case-study heroes use real, scrollable
live previews of client sites inside iframes. External sites must be
whitelisted in the CSP `frame-src` directive (all pages + `_headers` +
`.htaccess`). Currently whitelisted: `https://thephonemark.com` (bolt-built,
no X-Frame-Options). Any other external client site needs the same line
updated — and that site must not send `X-Frame-Options: DENY/SAMEORIGIN` or a
restrictive `frame-ancestors`.
