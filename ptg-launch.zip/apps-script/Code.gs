/* ============================================================
   PTG SITES — OPTIONAL BACKEND (Google Apps Script)
   ------------------------------------------------------------
   Makes the site's lead capture multi-device: every submission
   is emailed to you and stored in a spreadsheet.

   SETUP (5 minutes):
   1. Go to https://script.google.com and create a new project.
   2. Paste this file in as Code.gs.
   3. Run the `setup` function once (authorize it) to create the
      spreadsheet and log its URL.
   4. Deploy → New deployment → Web app:
        - Execute as: Me
        - Who has access: Anyone
      Copy the /exec URL.
   5. Open ptg/data.js and paste it into:
        PTG.settings.backend.url = "https://script.google.com/macros/s/…/exec"
   6. Re-deploy with "new version" whenever you change Code.gs.

   Submissions from the site arrive as POST bodies with a `type`
   field: "lead" | "appointment" | "audit" | "request".
   ============================================================ */

var SHEET_URL_KEY = 'PTG_SHEET_URL';

function setup() {
  var ss = SpreadsheetApp.create('PTG Sites — Inbox');
  ['Leads', 'Appointments', 'Audits', 'Requests'].forEach(function (name) {
    ss.insertSheet(name);
    ss.getSheetByName(name).appendRow(['Timestamp', 'JSON', 'Quality']);
  });
  ss.deleteSheet(ss.getSheetByName('Sheet1'));
  PropertiesService.getScriptProperties().setProperty(SHEET_URL_KEY, ss.getUrl());
  Logger.log('Spreadsheet created: ' + ss.getUrl());
}

function doPost(e) {
  var body = {};
  try { body = JSON.parse(e.postData.contents); } catch (err) { body = { raw: e.postData.contents }; }

  var sheetName = {
    lead: 'Leads',
    appointment: 'Appointments',
    audit: 'Audits',
    request: 'Requests'
  }[body.type] || 'Leads';

  var url = PropertiesService.getScriptProperties().getProperty(SHEET_URL_KEY);
  var ss = url ? SpreadsheetApp.openByUrl(url) : SpreadsheetApp.create('PTG Sites — Inbox');
  var sheet = ss.getSheetByName(sheetName);
  if (!sheet) { sheet = ss.insertSheet(sheetName); sheet.appendRow(['Timestamp', 'JSON', 'Quality']); }
  sheet.appendRow([new Date(), JSON.stringify(body), body.quality || '']);

  // Admin notification + confirmation email
  var settings = getSettings();
  var to = body.email || settings.adminEmail;
  var admin = settings.adminEmail;
  var subject = {
    lead: 'PTG: New lead (' + (body.quality || '?') + ') — ' + (body.business || body.name || ''),
    appointment: 'PTG: New call booked — ' + (body.name || ''),
    audit: 'PTG: New audit request — ' + (body.url || ''),
    request: 'PTG: New maintenance request'
  }[body.type] || 'PTG: New submission';

  if (admin) {
    MailApp.sendEmail({ to: admin, subject: subject, body: JSON.stringify(body, null, 2) });
  }
  if (to && body.type !== 'request') {
    MailApp.sendEmail({
      to: to,
      subject: 'Thanks for reaching out to PTG Sites',
      body: "Thanks for reaching out to PTG Sites.\n\nWe've received your " +
            (body.type === 'audit' ? 'audit request' : body.type === 'appointment' ? 'call request' : 'project request') +
            " and will review it shortly — expect to hear from us within one business day.\n\n— PTG Sites\nhttps://ptgsites.com"
    });
  }
  return ContentService.createTextOutput(JSON.stringify({ ok: true })).setMimeType(ContentService.MimeType.JSON);
}

function doGet() {
  return ContentService.createTextOutput('PTG backend is live.').setMimeType(ContentService.MimeType.TEXT);
}

/* Edit these to match your PTG.settings values */
function getSettings() {
  return {
    adminEmail: 'hello@ptgsites.com',
    domain: 'https://ptgsites.com'
  };
}